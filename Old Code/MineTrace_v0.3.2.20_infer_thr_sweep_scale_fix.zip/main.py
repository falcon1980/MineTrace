
import os
import sys
import json
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction, QColor
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QFileDialog, QMessageBox, QSplitter, QWidget,
    QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QListWidget, QListWidgetItem, QGroupBox,
    QFormLayout, QSpinBox, QDoubleSpinBox, QSlider, QCheckBox
)

from mt.project import Project
from mt.image_io import load_document_to_numpy
from mt.tiling import suggest_tiles, clamp_tile_size
from mt.viewer import ImageViewer
from mt.label_dialog import LabelTileDialog
from mt.dxf_export import export_project_to_dxf, export_predictions_to_dxf
from mt.processes import TrainProcess, InferProcess
from mt.import_legacy import import_legacy_labeled_tiles
from mt.channels import load_channels, ChannelSpec


APP_NAME = "MineTrace (v0.3.2.18)"

CHANGELOG = [
    ("v0.3.1", "Channels UI (pillars/walls), UI training saves raw+labels+mask, per-channel DXF layers"),
    ("v0.3.0", "Plumbing: channels registry + training-set labels import/export"),
    ("v0.2.8.0", "UI: slider value readouts; export overlay uses UI thresholds; Help menu fixes"),
    ("v0.2.7.5", "Training pipeline fixes; maximize startup"),
    ("v0.2.7.0", "Arc preview improvements; Esc abort; clear suggested tiles"),
    ("v0.2.6.0", "Export/Import training set"),
    ("v0.2.5.0", "Arc tool + live preview")
]



class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(1480, 950)

        self.project: Project | None = None
        self.current_doc_id: str | None = None
        self.current_image = None  # numpy array (H,W,3) uint8

        self.train_proc = TrainProcess(self)
        self.train_proc.finished.connect(self.on_train_finished)
        self.infer_proc = InferProcess(self)
        self.infer_proc.finished.connect(self.on_infer_finished)
        # Channels (v0.3.1): loaded from channels/channels.json
        self.channels: list[ChannelSpec] = load_channels(Path(__file__).resolve().parent)
        self.channel_checks: dict[str, QCheckBox] = {}

        self._build_menu()
        self._build_ui()

    def _build_menu(self):
        menu = self.menuBar()

        file_menu = menu.addMenu("&File")
        act_new = QAction("New Project...", self)
        act_open = QAction("Open Project...", self)
        act_add_doc = QAction("Add Document...", self)
        act_export_dxf = QAction("Export DXF (labels only)...", self)
        act_export_pred_dxf = QAction("Export DXF (predictions)...", self)
        act_quit = QAction("Quit", self)

        act_new.triggered.connect(self.new_project)
        act_open.triggered.connect(self.open_project)
        act_add_doc.triggered.connect(self.add_document)
        act_export_dxf.triggered.connect(self.export_dxf_labels)
        act_export_pred_dxf.triggered.connect(self.export_dxf_predictions)
        act_quit.triggered.connect(self.close)

        file_menu.addAction(act_new)
        file_menu.addAction(act_open)
        self.recent_menu = file_menu.addMenu("Open Recent")
        self.recent_menu.aboutToShow.connect(self._refresh_recent_menu)
        self._refresh_recent_menu()
        file_menu.addSeparator()
        file_menu.addAction(act_add_doc)
        file_menu.addSeparator()
        file_menu.addAction(act_export_dxf)
        file_menu.addAction(act_export_pred_dxf)
        file_menu.addSeparator()
        file_menu.addAction(act_quit)

        tools_menu = menu.addMenu("&Tools")
        help_menu = menu.addMenu("&Help")

        act_about = QAction("About", self)
        act_help = QAction("Help", self)
        act_about.triggered.connect(self.on_about)
        act_help.triggered.connect(self.on_help)
        help_menu.addAction(act_about)
        help_menu.addAction(act_help)
        act_notes = QAction("Release Notes", self)
        act_notes.triggered.connect(self.on_release_notes)
        help_menu.addSeparator()
        help_menu.addAction(act_notes)
        act_import_legacy = QAction("Import legacy labeled tiles...", self)
        act_import_legacy.triggered.connect(self.import_legacy)
        tools_menu.addAction(act_import_legacy)

    def _load_changelog(self):
        try:
            p = Path(__file__).resolve().parent / "mt" / "changelog.json"
            if not p.exists():
                p = Path(__file__).resolve().parent / "changelog.json"
            return json.loads(p.read_text(encoding="utf-8")) if p.exists() else []
        except Exception:
            return []

    def on_about(self):
        recent = "\n".join([f"{v} - {d}" for v, d in CHANGELOG[:5]])
        QMessageBox.information(self, "About",
                                f"{APP_NAME}\n\nWritten & developed by Garrett Cockrum & ChatGPT\n\nRecent Updates:\n{recent}")

    def on_release_notes(self):
        txt = "\n".join([f"{v} - {d}" for v, d in CHANGELOG])
        QMessageBox.information(self, "Release Notes", txt)

    def on_help(self):
        QMessageBox.information(self, "Help",
                                "Please contact Garrett Cockrum at garrett.cockrum@stantec.com")

    def on_export_training_set(self):
        if not self.project:
            QMessageBox.warning(self, "No Project", "Open or create a project first.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export Training Set", "", "Zip Files (*.zip)")
        if not path:
            return
        try:
            stats = self.project.export_training_set(path)
            QMessageBox.information(self, "Export Complete",
                                    f"Exported training set.\nImages: {stats.get('images',0)}\nMasks: {stats.get('masks',0)}")
        except Exception as e:
            QMessageBox.critical(self, "Export Failed", str(e))

    def on_import_training_set(self):
        if not self.project:
            QMessageBox.warning(self, "No Project", "Open or create a project first.")
            return
        path, _ = QFileDialog.getOpenFileName(self, "Import Training Set", "", "Zip Files (*.zip)")
        if not path:
            return
        try:
            stats = self.project.import_training_set(path)
            QMessageBox.information(self, "Import Complete",
                                    f"Imported training set.\nImages: {stats.get('images',0)}\nMasks: {stats.get('masks',0)}")
        except Exception as e:
            QMessageBox.critical(self, "Import Failed", str(e))

    def _update_slider_labels(self):
        self.lbl_thr_pillars.setText(str(self.sl_thr_pillars.value()))
        self.lbl_thr_walls.setText(str(self.sl_thr_walls.value()))
        self.lbl_gap.setText(str(self.sl_gap.value()))
        self.lbl_merge.setText(str(self.sl_merge.value()))
        self.lbl_simplify.setText(str(self.sl_simplify.value()))

    
    # -------------------------
    # Recent projects helpers
    # -------------------------
    def _recent_store_path(self) -> Path:
        base = Path(os.path.expanduser("~")) / ".minetrace"
        base.mkdir(parents=True, exist_ok=True)
        return base / "recent_projects.json"

    def _load_recent_projects(self):
        p = self._recent_store_path()
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(data, list):
                # keep only existing paths
                out = []
                for s in data:
                    try:
                        sp = Path(s)
                        if sp.exists():
                            out.append(str(sp))
                    except Exception:
                        pass
                return out[:10]
        except Exception:
            pass
        # Default starter recent path(s)
        default = r"C:\MineTrace\Projects\Lower Elkhorn"
        try:
            if Path(default).exists():
                return [default]
        except Exception:
            pass
        return []

    def _save_recent_projects(self, items):
        p = self._recent_store_path()
        try:
            p.write_text(json.dumps(items[:10], indent=2), encoding="utf-8")
        except Exception:
            pass

    def _add_recent_project(self, proj_path: str):
        items = self._load_recent_projects()
        proj_path = str(Path(proj_path).resolve())
        items = [p for p in items if p != proj_path]
        items.insert(0, proj_path)
        self._save_recent_projects(items)

    def _refresh_recent_menu(self):
        if not hasattr(self, "recent_menu") or self.recent_menu is None:
            return
        self.recent_menu.clear()
        items = self._load_recent_projects()
        if not items:
            a = QAction("(none)", self)
            a.setEnabled(False)
            self.recent_menu.addAction(a)
            return

        for p in items:
            act = QAction(p, self)
            act.triggered.connect(lambda checked=False, pp=p: self.open_project_path(pp))
            self.recent_menu.addAction(act)

    def _build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        layout = QHBoxLayout(root)

        splitter = QSplitter(Qt.Horizontal)
        layout.addWidget(splitter)

        # Left panel: docs + tiles + settings
        left = QWidget()
        left_layout = QVBoxLayout(left)

        self.lbl_project = QLabel("Project: (none)")
        self.lbl_project.setWordWrap(True)
        left_layout.addWidget(self.lbl_project)

        doc_box = QGroupBox("Documents")
        doc_layout = QVBoxLayout(doc_box)
        self.doc_list = QListWidget()
        self.doc_list.currentRowChanged.connect(self.on_doc_selected)
        doc_layout.addWidget(self.doc_list)
        btn_add_doc = QPushButton("Add Document…")
        btn_add_doc.clicked.connect(self.add_document)
        doc_layout.addWidget(btn_add_doc)
        left_layout.addWidget(doc_box)

        tile_box = QGroupBox("Training Tile Generator")
        tile_layout = QVBoxLayout(tile_box)
        self.tile_list = QListWidget()
        self.tile_list.itemDoubleClicked.connect(self.open_tile_for_labeling)
        tile_layout.addWidget(self.tile_list)

        controls = QWidget()
        c_layout = QFormLayout(controls)

        self.sp_tile = QSpinBox()
        self.sp_tile.setRange(128, 512)
        self.sp_tile.setValue(512)

        self.sl_overlap = QSlider(Qt.Horizontal)
        self.sl_overlap.setRange(0, 80)  # percent
        self.sl_overlap.setValue(25)
        self.lbl_overlap_val = QLabel("25%")

        self.sp_suggest = QSpinBox()
        self.sp_suggest.setRange(10, 500)
        self.sp_suggest.setValue(80)

        self.sp_tile.valueChanged.connect(self._on_tile_params_changed)
        self.sl_overlap.valueChanged.connect(self._on_tile_params_changed)
        self.sp_suggest.valueChanged.connect(self._on_tile_params_changed)

        c_layout.addRow("Max tile size", self.sp_tile)
        ov_w = QWidget()
        ov_l = QHBoxLayout(ov_w)
        ov_l.setContentsMargins(0, 0, 0, 0)
        ov_l.addWidget(self.sl_overlap)
        ov_l.addWidget(self.lbl_overlap_val)
        c_layout.addRow("Overlap", ov_w)
        c_layout.addRow("# of Tiles", self.sp_suggest)
        tile_layout.addWidget(controls)

        self.lbl_tile_info = QLabel("")
        self.lbl_tile_info.setWordWrap(True)
        tile_layout.addWidget(self.lbl_tile_info)

        legacy_box = QGroupBox("Legacy import speck filter")
        legacy_form = QFormLayout(legacy_box)
        self.sp_legacy_yellow = QSpinBox()
        self.sp_legacy_yellow.setRange(0, 5000)
        self.sp_legacy_yellow.setValue(8)
        self.sp_legacy_cyan = QSpinBox()
        self.sp_legacy_cyan.setRange(0, 5000)
        self.sp_legacy_cyan.setValue(50)
        legacy_form.addRow("Min pixels (Pillars/yellow)", self.sp_legacy_yellow)
        legacy_form.addRow("Min pixels (Walls/cyan)", self.sp_legacy_cyan)
        tile_layout.addWidget(legacy_box)

        btn_row = QWidget()
        b_layout = QHBoxLayout(btn_row)
        self.btn_suggest = QPushButton("Auto Tile")
        self.btn_manual_tile = QPushButton("Manual Tile")
        self.btn_clear_suggested = QPushButton("Clear Suggested Tiles")
        self.btn_suggest.clicked.connect(self.run_tile_suggestions)
        self.btn_manual_tile.clicked.connect(self.manual_tile_mode)
        self.btn_clear_suggested.clicked.connect(self.clear_suggested_tiles)
        b_layout.addWidget(self.btn_suggest)
        b_layout.addWidget(self.btn_manual_tile)
        b_layout.addWidget(self.btn_clear_suggested)
        tile_layout.addWidget(btn_row)

        self.chk_hide_rejected = QCheckBox("Hide rejected")
        self.chk_hide_rejected.setChecked(True)
        self.chk_hide_rejected.stateChanged.connect(self.refresh_tile_list)
        tile_layout.addWidget(self.chk_hide_rejected)

        left_layout.addWidget(tile_box)

        # Predict display + settings
        pred_box = QGroupBox("Preview (predictions)")
        p_layout = QVBoxLayout(pred_box)

        # Channel selection (from channels/channels.json)
        self.channel_checks = {}
        for ch in self.channels:
            cb = QCheckBox(f"Show {ch.display_name}")
            cb.setChecked(True)
            cb.stateChanged.connect(self.apply_overlay_settings)
            self.channel_checks[ch.id] = cb
            p_layout.addWidget(cb)
        self.chk_show_pillars = self.channel_checks.get('pillars')  # legacy
        self.chk_show_walls = self.channel_checks.get('walls')      # legacy

        # Tile-based inference controls
        self.sp_inf_tile = QSpinBox()
        self.sp_inf_tile.setRange(64, 512)
        self.sp_inf_tile.setSingleStep(32)
        self.sp_inf_tile.setValue(128)
        self.sp_inf_overlap = QDoubleSpinBox()
        self.sp_inf_overlap.setRange(0.0, 0.9)
        self.sp_inf_overlap.setSingleStep(0.05)
        self.sp_inf_overlap.setDecimals(2)
        self.sp_inf_overlap.setValue(0.50)
        row_inf = QWidget()
        row_inf_l = QHBoxLayout(row_inf)
        row_inf_l.setContentsMargins(0,0,0,0)
        row_inf_l.addWidget(QLabel("Infer tile"))
        row_inf_l.addWidget(self.sp_inf_tile)
        row_inf_l.addSpacing(12)
        row_inf_l.addWidget(QLabel("Overlap"))
        row_inf_l.addWidget(self.sp_inf_overlap)
        p_layout.addWidget(row_inf)

        self.sl_thr_pillars = QSlider(Qt.Horizontal)
        self.sl_thr_walls = QSlider(Qt.Horizontal)
        for s in (self.sl_thr_pillars, self.sl_thr_walls):
            s.setRange(0, 255)
            s.setValue(140)
            s.valueChanged.connect(self.apply_overlay_settings)

        self.sl_gap = QSlider(Qt.Horizontal)
        self.sl_gap.setRange(0, 10)  # pixels
        self.sl_gap.setValue(2)
        self.sl_gap.valueChanged.connect(self.apply_overlay_settings)

        self.sl_merge = QSlider(Qt.Horizontal)
        self.sl_merge.setRange(0, 10)  # pixels
        self.sl_merge.setValue(1)
        self.sl_merge.valueChanged.connect(self.apply_overlay_settings)

        self.sl_simplify = QSlider(Qt.Horizontal)
        self.sl_simplify.setRange(0, 10)
        self.sl_simplify.setValue(2)
        self.sl_simplify.valueChanged.connect(self.apply_overlay_settings)

        # Value readouts for sliders
        # Value readouts for sliders (shown at right of each slider)
        self.lbl_thr_pillars = QLabel(str(self.sl_thr_pillars.value()))
        self.lbl_thr_pillars.setMinimumWidth(48)
        self.lbl_thr_pillars.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.lbl_thr_walls = QLabel(str(self.sl_thr_walls.value()))
        self.lbl_thr_walls.setMinimumWidth(48)
        self.lbl_thr_walls.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.lbl_gap = QLabel(str(self.sl_gap.value()))
        self.lbl_gap.setMinimumWidth(48)
        self.lbl_gap.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.lbl_merge = QLabel(str(self.sl_merge.value()))
        self.lbl_merge.setMinimumWidth(48)
        self.lbl_merge.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.lbl_simplify = QLabel(str(self.sl_simplify.value()))
        self.lbl_simplify.setMinimumWidth(48)
        self.lbl_simplify.setAlignment(Qt.AlignRight | Qt.AlignVCenter)

        def _update_pred_labels():
            # guard against deleted widgets during UI rebuilds
            try: self.lbl_thr_pillars.setText(str(self.sl_thr_pillars.value()))
            except Exception: pass
            try: self.lbl_thr_walls.setText(str(self.sl_thr_walls.value()))
            except Exception: pass
            try: self.lbl_gap.setText(str(self.sl_gap.value()))
            except Exception: pass
            try: self.lbl_merge.setText(str(self.sl_merge.value()))
            except Exception: pass
            try: self.lbl_simplify.setText(str(self.sl_simplify.value()))
            except Exception: pass

        # Update labels whenever sliders move (avoid lambdas capturing soon-to-be-deleted QLabel objects)
        self.sl_thr_pillars.valueChanged.connect(lambda _v: _update_pred_labels())
        self.sl_thr_walls.valueChanged.connect(lambda _v: _update_pred_labels())
        self.sl_gap.valueChanged.connect(lambda _v: _update_pred_labels())
        self.sl_merge.valueChanged.connect(lambda _v: _update_pred_labels())
        self.sl_simplify.valueChanged.connect(lambda _v: _update_pred_labels())
        _update_pred_labels()

        form = QFormLayout()
        def _h(sl, lbl):
            row = QWidget()
            h = QHBoxLayout(row)
            h.setContentsMargins(0,0,0,0)
            h.addWidget(sl, 1)
            h.addWidget(lbl, 0)
            return row

        form.addRow("Pillars threshold", _h(self.sl_thr_pillars, self.lbl_thr_pillars))
        form.addRow("Walls threshold", _h(self.sl_thr_walls, self.lbl_thr_walls))
        form.addRow("Bridge gaps (px)", _h(self.sl_gap, self.lbl_gap))
        form.addRow("Merge radius (px)", _h(self.sl_merge, self.lbl_merge))
        form.addRow("Simplify (0-10)", _h(self.sl_simplify, self.lbl_simplify))
        p_layout.addLayout(form)

        left_layout.addWidget(pred_box)

        train_box = QGroupBox("Train / Predict")
        t_layout = QVBoxLayout(train_box)

        # Dice target (passed to training worker via env)
        target_row = QWidget()
        target_row_l = QHBoxLayout(target_row)
        target_row_l.setContentsMargins(0, 0, 0, 0)
        target_row_l.addWidget(QLabel("Dice target"))
        self.sp_target_dice = QDoubleSpinBox()
        self.sp_target_dice.setRange(0.0, 1.0)
        self.sp_target_dice.setSingleStep(0.01)
        self.sp_target_dice.setDecimals(2)
        self.sp_target_dice.setValue(0.90)
        target_row_l.addWidget(self.sp_target_dice, 1)
        t_layout.addWidget(target_row)

        self.btn_train = QPushButton("Train (incremental)")
        self.btn_reset = QPushButton("Reset / Flush training")
        self.btn_infer = QPushButton("Predict Current Image")
        self.btn_train.clicked.connect(self.train_clicked)
        self.btn_reset.clicked.connect(self.reset_clicked)
        self.btn_infer.clicked.connect(self.infer_clicked)
        t_layout.addWidget(self.btn_train)
        t_layout.addWidget(self.btn_reset)
        t_layout.addWidget(self.btn_infer)
        left_layout.addWidget(train_box)

        left_layout.addStretch(1)

        # Right: image viewer
        right = QWidget()
        right_layout = QVBoxLayout(right)
        self.viewer = ImageViewer()
        right_layout.addWidget(self.viewer)

        splitter.addWidget(left)
        splitter.addWidget(right)
        splitter.setSizes([470, 1010])

        self._set_enabled(False)

    def _set_enabled(self, enabled: bool):
        self.btn_suggest.setEnabled(enabled)
        self.btn_manual_tile.setEnabled(enabled)
        self.btn_train.setEnabled(enabled)
        self.btn_reset.setEnabled(enabled)
        self.btn_infer.setEnabled(enabled)

    # ---------- Project actions ----------
    def new_project(self):
        folder = QFileDialog.getExistingDirectory(self, "Choose new project folder")
        if not folder:
            return
        Path(folder).mkdir(parents=True, exist_ok=True)
        try:
            self.project = Project.create(folder)
        except Exception as e:
            QMessageBox.critical(self, "Create Project Failed", str(e))
            return
        self.lbl_project.setText(f"Project: {folder}")
        self.doc_list.clear()
        self.tile_list.clear()
        self.viewer.clear_overlays()
        self._set_enabled(True)

    def open_project_path(self, proj_path: str):
        try:
            proj_path = str(Path(proj_path).resolve())
            if not Path(proj_path).exists():
                QMessageBox.warning(self, "Project not found", f"{proj_path}")
                return
            self.project_root = proj_path
            self._load_project()
            self._add_recent_project(proj_path)
        except Exception as e:
            QMessageBox.critical(self, "Open project failed", str(e))

    def open_project(self):
        folder = QFileDialog.getExistingDirectory(self, "Open project folder")
        if not folder:
            return
        try:
            self.project = Project.load(folder)
        except Exception as e:
            QMessageBox.critical(self, "Open Project Failed", str(e))
            return
        self.lbl_project.setText(f"Project: {folder}")
        self._reload_docs()
        self._set_enabled(True)

    def add_document(self):
        if not self.project:
            QMessageBox.information(self, "No Project", "Create or open a project first.")
            return

        path, _ = QFileDialog.getOpenFileName(
            self, "Add document",
            filter="Images/PDF (*.tif *.tiff *.png *.jpg *.jpeg *.pdf)"
        )
        if not path:
            return

        try:
            doc_id = self.project.add_document(path)
        except Exception as e:
            QMessageBox.critical(self, "Add Document Failed", str(e))
            return

        self._reload_docs(select_doc_id=doc_id)

    def import_legacy(self):
        if not self.project:
            QMessageBox.information(self, "No Project", "Create or open a project first.")
            return
        folder = QFileDialog.getExistingDirectory(self, "Select folder containing legacy labeled tile images")
        if not folder:
            return
        try:
            stats = import_legacy_labeled_tiles(self.project, folder,
                data_root_override=os.environ.get("MT_DATA_ROOT", r"C:\\MineTrace\\data"),
                min_area_yellow=int(getattr(self, 'sp_legacy_yellow').value()) if hasattr(self, 'sp_legacy_yellow') else 8,
                min_area_cyan=int(getattr(self, 'sp_legacy_cyan').value()) if hasattr(self, 'sp_legacy_cyan') else 50
            )
        except Exception as e:
            QMessageBox.critical(self, "Import Failed", str(e))
            return
        extra = ""
        if "noise_filtered" in stats:
            extra = f"\nNoise-filtered: {stats['noise_filtered']}"
        QMessageBox.information(self, "Import Complete", f"Imported {stats.get('imported', stats.get('imported_tiles', stats.get('imported_count', 0)))} tiles.\nSkipped {stats.get('skipped', stats.get('skipped_tiles', stats.get('skipped_count', 0)))}.{extra}")

    def _reload_docs(self, select_doc_id: str | None = None):
        assert self.project
        self.doc_list.clear()
        docs = self.project.list_documents()
        for d in docs:
            self.doc_list.addItem(f"{d.doc_id}  |  {Path(d.original_path).name}")
        if select_doc_id:
            for i, d in enumerate(docs):
                if d.doc_id == select_doc_id:
                    self.doc_list.setCurrentRow(i)
                    break
        elif docs:
            self.doc_list.setCurrentRow(0)

    def on_doc_selected(self, row: int):
        if not self.project:
            return
        docs = self.project.list_documents()
        if row < 0 or row >= len(docs):
            return
        doc = docs[row]
        self.current_doc_id = doc.doc_id

        try:
            img = load_document_to_numpy(doc.cache_path)
        except Exception as e:
            QMessageBox.critical(self, "Load Failed", f"Could not load cached document:\n{e}")
            return

        self.current_image = img
        self.viewer.set_image(img)
        self.viewer.clear_overlays()
        self._on_tile_params_changed()
        self.refresh_tile_list()
        self._try_load_prediction_overlays()

    
    def _on_tile_params_changed(self):
        if not (self.project and self.current_image is not None):
            return
        tile = clamp_tile_size(self.current_image.shape[1], self.current_image.shape[0], int(self.sp_tile.value()))
        overlap = int(self.sl_overlap.value()) / 100.0
        self._update_tile_info(tile, overlap)

    def _update_tile_info(self, tile: int, overlap: float):
        if not hasattr(self, "lbl_tile_info"):
            return
        step = max(32, int(tile * (1.0 - overlap)))
        if self.current_image is not None:
            h, w = self.current_image.shape[:2]
            nx = max(1, ((w - tile) // step) + 1) if w >= tile else 1
            ny = max(1, ((h - tile) // step) + 1) if h >= tile else 1
            cand = nx * ny
        else:
            cand = 0
        self.lbl_tile_info.setText(f"Tile={tile}px | Step={step}px | Overlap={int(overlap*100)}% | Step={step}px | Candidates≈{cand}")
        if hasattr(self, "lbl_overlap_val"):
            self.lbl_overlap_val.setText(f"{int(overlap*100)}%")


    def _load_changelog(self):
        try:
            p = Path(__file__).resolve().parent / "mt" / "changelog.json"
            if not p.exists():
                p = Path(__file__).resolve().parent / "changelog.json"
            return json.loads(p.read_text(encoding="utf-8")) if p.exists() else []
        except Exception:
            return []

    def on_about(self):
        recent = "\n".join([f"{v} - {d}" for v, d in CHANGELOG[:5]])
        QMessageBox.information(self, "About",
                                f"{APP_NAME}\n\nWritten & developed by Garrett Cockrum & ChatGPT\n\nRecent Updates:\n{recent}")

    def on_release_notes(self):
        txt = "\n".join([f"{v} - {d}" for v, d in CHANGELOG])
        QMessageBox.information(self, "Release Notes", txt)

    def on_help(self):
        QMessageBox.information(self, "Help",
                                "Please contact Garrett Cockrum at garrett.cockrum@stantec.com")

    # ---------- Tiling ----------


    def clear_suggested_tiles(self):
        if not (self.project and self.current_doc_id):
            QMessageBox.warning(self, "No Document", "Load a document first.")
            return
        tiles = self.project.list_tiles(self.current_doc_id)
        n = sum(1 for t in tiles if t.status == "suggested")
        if n == 0:
            QMessageBox.information(self, "Nothing to Clear", "There are no suggested tiles to clear.")
            return
        ok = QMessageBox.question(self, "Clear Suggested Tiles",
                                  f"Remove {n} suggested tile(s)?\n\nAccepted and rejected tiles will be kept.")
        if ok != QMessageBox.Yes:
            return
        self.project.clear_suggested_tiles_for_doc(self.current_doc_id)
        self.refresh_tile_list()

    def run_tile_suggestions(self):
        if not (self.project and self.current_doc_id and self.current_image is not None):
            return

        max_tile = int(self.sp_tile.value())
        tile = clamp_tile_size(self.current_image.shape[1], self.current_image.shape[0], max_tile)
        overlap = int(self.sl_overlap.value()) / 100.0
        n = int(self.sp_suggest.value())

        self.project.clear_suggested_tiles_for_doc(self.current_doc_id)
        tiles = suggest_tiles(self.current_image, tile_size=tile, overlap=overlap, top_k=n)
        self.project.add_suggested_tiles(self.current_doc_id, tiles)
        self._update_tile_info(tile, overlap)
        self.refresh_tile_list()

    def manual_tile_mode(self):
        if not (self.project and self.current_doc_id and self.current_image is not None):
            return
        rect = self.viewer.get_manual_rect()
        if rect is None:
            QMessageBox.information(self, "Manual Tile", "Drag a rectangle on the image first (right panel), then click Manual Tile again.")
            return
        x, y, w, h = rect
        max_tile = int(self.sp_tile.value())
        size = min(max_tile, max(w, h))
        size = max(128, min(512, size))
        self.project.add_manual_tile(self.current_doc_id, x, y, size, size)
        self.refresh_tile_list()

    def refresh_tile_list(self):
        if not (self.project and self.current_doc_id):
            return
        self.tile_list.clear()
        hide_rej = self.chk_hide_rejected.isChecked()

        tiles = self.project.list_tiles(self.current_doc_id)
        for t in tiles:
            if hide_rej and t.status == "rejected":
                continue

            text = f"{t.tile_id}  [{t.status}]  x={t.x},y={t.y},s={t.w} score={t.score:.3f}"

            item = QListWidgetItem()
            # Build a custom row widget with right-aligned status icon
            row = QWidget()
            row.setAttribute(Qt.WA_TransparentForMouseEvents, True)
            lay = QHBoxLayout(row)
            lay.setContentsMargins(10, 6, 10, 6)

            lbl = QLabel(text)
            lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
            lay.addWidget(lbl, 1)

            icon = QLabel("")
            icon.setFixedWidth(18)
            icon.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            lay.addWidget(icon, 0)

            # Style by status
            if t.status == "accepted":
                icon.setText("✓")
                row.setStyleSheet(
                    "QWidget{background-color:#163b1e;border:1px solid #2b6a38;border-radius:6px;}"
                    "QLabel{color:#e7f6ea;}"
                )
            elif t.status == "rejected":
                icon.setText("✕")
                row.setStyleSheet(
                    "QWidget{background-color:#3b1616;border:1px solid #6a2b2b;border-radius:6px;}"
                    "QLabel{color:#f6e7e7;}"
                )
            else:
                row.setStyleSheet(
                    "QWidget{background-color:transparent;border-radius:6px;}"
                )

            # Size hint
            item.setSizeHint(row.sizeHint())
            self.tile_list.addItem(item)
            self.tile_list.setItemWidget(item, row)

    def open_tile_for_labeling(self):
        if not (self.project and self.current_doc_id and self.current_image is not None):
            return
        row = self.tile_list.currentRow()
        if row < 0:
            return

        visible = []
        hide_rej = self.chk_hide_rejected.isChecked()
        for t in self.project.list_tiles(self.current_doc_id):
            if hide_rej and t.status == "rejected":
                continue
            visible.append(t)

        if row >= len(visible):
            return
        tile = visible[row]

        x, y, w, h = tile.x, tile.y, tile.w, tile.h
        img = self.current_image
        crop = img[y:y+h, x:x+w].copy()

        dlg = LabelTileDialog(
            project=self.project,
            doc_id=self.current_doc_id,
            tile=tile,
            tile_image=crop,
            parent=self
        )
        dlg.exec()
        self.refresh_tile_list()

    # ---------- Train / Infer ----------
    
    def _selected_channel_ids(self) -> list[str]:
        ids: list[str] = []
        if getattr(self, "channel_checks", None):
            for ch in self.channels:
                cb = self.channel_checks.get(ch.id)
                if cb and cb.isChecked():
                    ids.append(ch.id)
        else:
            # fallback legacy checkboxes
            if getattr(self, "chk_show_pillars", None) and self.chk_show_pillars.isChecked():
                ids.append("pillars")
            if getattr(self, "chk_show_walls", None) and self.chk_show_walls.isChecked():
                ids.append("walls")
        return ids

    def _channel_env(self, channel_id: str) -> dict:
        # Persistent roots (keeps you from copying datasets between app zips)
        data_root = os.environ.get("MT_DATA_ROOT", r"C:\MineTrace\data")
        model_root = os.environ.get("MT_MODEL_ROOT", r"C:\MineTrace\models")
        env = {
            "MT_DATA_ROOT": data_root,
            "MT_MODEL_ROOT": model_root,
            "MT_CHANNEL": channel_id,
        }
        # training mask parsing / inference output color
        if channel_id.lower().startswith("wall"):
            env["MT_POS_COLOR"] = "cyan"
            env["MT_IGNORE_CYAN"] = "0"
        else:
            env["MT_POS_COLOR"] = "yellow"
            env["MT_IGNORE_CYAN"] = "1"
        return env

    def on_train_finished(self):
        # Continue queued multi-channel training
        if getattr(self, "_train_queue", None):
            if self._train_queue:
                next_ch = self._train_queue.pop(0)
                self._start_train_for_channel(next_ch)

    def _start_train_for_channel(self, channel_id: str):
        if not self.project:
            return
        env = self._channel_env(channel_id)

        # UI-controlled dice target (falls back to 0.90 in worker)
        try:
            tgt = float(self.sp_target_dice.value())
        except Exception:
            tgt = 0.90
        env["MT_CHECK_TARGET_DICE"] = f"{tgt:.2f}"
        # Back-compat name (some older scripts use this)
        env["MT_CHECK_TARGET"] = env["MT_CHECK_TARGET_DICE"]
        # Export labeled tiles into the persistent per-channel dataset
        from pathlib import Path as _Path
        data_root = _Path(env["MT_DATA_ROOT"])  # global data root; channel applied separately
        self.project.ensure_training_data_from_labels(channel_id=channel_id, data_root_override=data_root)
        self.train_proc.start(self.project.root, env_overrides=env)

    def train_clicked(self):
        if not self.project:
            return
        chs = self._selected_channel_ids()
        if not chs:
            QMessageBox.information(self, "Train", "No channels selected.")
            return
        # queue: train channels sequentially
        self._train_queue = chs[1:]
        self._start_train_for_channel(chs[0])

    def reset_clicked(self):
        if not self.project:
            return
        ok = QMessageBox.question(
            self, "Reset Training",
            "Delete checkpoints and exports for this project?\n\n(Your labels and training tiles stay.)"
        )
        if ok != QMessageBox.Yes:
            return
        self.project.reset_training()
        self.viewer.clear_overlays()
        QMessageBox.information(self, "Reset", "Training and exports cleared.")

    def infer_clicked(self):
        if not (self.project and self.current_doc_id):
            return
        ts = self.sp_inf_tile.value() if hasattr(self, 'sp_inf_tile') else 128
        ov = self.sp_inf_overlap.value() if hasattr(self, 'sp_inf_overlap') else 0.50
        chs = self._selected_channel_ids()
        if not chs:
            QMessageBox.information(self, "Predict", "No channels selected.")
            return
        self._infer_queue = chs[1:]
        # run first
        env = self._channel_env(chs[0])
        self.infer_proc.start(self.project.root, self.current_doc_id, self.sl_thr_pillars.value(), self.sl_thr_walls.value(), 160, ts, ov, env_overrides=env)

    def on_infer_finished(self):
        self._try_load_prediction_overlays()
        if getattr(self, "_infer_queue", None):
            if self._infer_queue:
                next_ch = self._infer_queue.pop(0)
                ts = self.sp_inf_tile.value() if hasattr(self, 'sp_inf_tile') else 128
                ov = self.sp_inf_overlap.value() if hasattr(self, 'sp_inf_overlap') else 0.50
                env = self._channel_env(next_ch)
                self.infer_proc.start(self.project.root, self.current_doc_id, self.sl_thr_pillars.value(), self.sl_thr_walls.value(), 160, ts, ov, env_overrides=env)

    def _try_load_prediction_overlays(self):
        if not (self.project and self.current_doc_id):
            return
        out_dir = Path(self.project.root) / "exports" / self.current_doc_id
        p1 = out_dir / "pred_pillars.png"
        p2 = out_dir / "pred_walls.png"
        if p1.exists() and p2.exists():
            self.viewer.set_overlays(str(p1), str(p2))
            self.apply_overlay_settings()

    def apply_overlay_settings(self):
        self.viewer.overlay_enabled = {
            "pillars": (self.channel_checks.get('pillars', self.chk_show_pillars).isChecked() if getattr(self,'channel_checks',None) else self.chk_show_pillars.isChecked()),
            "walls": (self.channel_checks.get('walls', self.chk_show_walls).isChecked() if getattr(self,'channel_checks',None) else self.chk_show_walls.isChecked()),
        }
        self.viewer.overlay_threshold = {
            "pillars": int(self.sl_thr_pillars.value()),
            "walls": int(self.sl_thr_walls.value()),
        }
        self.viewer.update()

    # ---------- Export ----------
    def export_dxf_labels(self):
        if not self.project:
            return
        out_path, _ = QFileDialog.getSaveFileName(self, "Export DXF (labels)", filter="DXF (*.dxf)")
        if not out_path:
            return
        try:
            export_project_to_dxf(self.project, out_path)
        except Exception as e:
            QMessageBox.critical(self, "DXF Export Failed", str(e))
            return
        QMessageBox.information(self, "DXF Export", f"Exported:\n{out_path}")

    def export_dxf_predictions(self):
        if not (self.project and self.current_doc_id):
            return
        out_path, _ = QFileDialog.getSaveFileName(self, "Export DXF (predictions)", filter="DXF (*.dxf)")
        if not out_path:
            return
        settings = {
            "thr_pillars": int(self.sl_thr_pillars.value()),
            "thr_walls": int(self.sl_thr_walls.value()),
            "bridge_gap": int(self.sl_gap.value()),
            "merge_radius": int(self.sl_merge.value()),
            "simplify": int(self.sl_simplify.value()),
        }
        try:
            export_predictions_to_dxf(self.project, self.current_doc_id, out_path, settings)
        except Exception as e:
            QMessageBox.critical(self, "Pred DXF Export Failed", str(e))
            return
        QMessageBox.information(self, "Pred DXF Export", f"Exported:\n{out_path}")


def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    win = MainWindow()
    win.showMaximized()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()