# MineTrace v0.3 Roadmap

## v0.3.0 (plumbing)
- [x] Base on v0.2.10.18
- [x] Add channel registry scaffold (pillars + walls)
- [x] Persistent roots remain supported (MT_DATA_ROOT / MT_MODEL_ROOT / MT_OUTPUT_ROOT)
- [x] Training set ZIP import/export supports optional `train/labels/`
- [ ] (Optional) Print resolved paths + counts in UI console output

## v0.3.1 (workflow + UI)
- [x] UI: dynamic channels from `channels.json` (Add Channel UI is still pending)
- [~] UI: labeling saves **raw + labeled + binary mask** (currently in project `train/` folders; per-channel folders pending)
- [ ] UI: run selected channels sequentially and composite overlays (yellow pillars, cyan walls, etc.)
- [x] DXF export: separate layers per channel (MT_PILLARS, MT_WALLS)
- [ ] Training UI: per-channel training button uses per-channel config (no console flags)
- [ ] Metrics: support multiple check pairs; report mean + min