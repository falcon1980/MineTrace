# MineTrace Changelog

## v0.3.2.1 (pre-release)
### Fixed
- Fixed an indentation error in main.py that prevented the app from launching.


## v0.3.1.1 (pre-release)
### Fixed
- Create `train/labels/` directory before saving labeled images (fixes Train button crash).

## v0.3.1 (pre-release)
**Focus: channel-aware UI + UI training artifacts + DXF layer naming.**

### Added
- UI: prediction show/hide checkboxes are now built from `channels/channels.json` (pillars + walls scaffold).
- UI labeling → training data generation now saves **human-reference** labeled images to `train/labels/*.png` (raw + colored strokes),
  in addition to `train/images/*.png` and `train/masks/*_mask.png`.
- DXF predicted export layers renamed to `MT_PILLARS` and `MT_WALLS` (clean layer separation).

### Notes
- Full “create channel” UI and per-channel training roots remain targeted for follow-up v0.3.x builds.

## v0.3.0 (pre-release)
**Focus: channel plumbing + training-set format upgrades (no major UI workflow changes yet).**

### Added
- Channel registry scaffold (pillars + walls) under `channels/channels.json`.
- Roadmap checklist `ROADMAP_v0.3.md` so we don’t lose track of v0.3.1 scope.

### Changed
- Training set ZIP import/export now supports an optional `train/labels/` folder (in addition to `train/images/` and `train/masks/`).
  - Legacy zips (images+masks only) still work.
  - Newer zips can include labels for human reference.
