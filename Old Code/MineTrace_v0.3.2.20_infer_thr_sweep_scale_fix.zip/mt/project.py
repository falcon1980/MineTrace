
import json
import shutil
import uuid
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

from .pdf_cache import cache_document


@dataclass
class DocumentRec:
    doc_id: str
    original_path: str
    cache_path: str
    kind: str


@dataclass
class TileRec:
    tile_id: str
    doc_id: str
    x: int
    y: int
    w: int
    h: int
    score: float
    status: str  # suggested | accepted | rejected


@dataclass
class PolylineRec:
    class_name: str
    thickness: int
    points: list[list[float]]  # tile coords


DEFAULT_CLASSES = [
    {"name": "Pillars", "layer": "PILLARS"},
    {"name": "Walls",   "layer": "WALLS"},
]


class Project:
    def __init__(self, root: str):
        self.root = str(Path(root).resolve())
        self._root = Path(self.root)

        self.meta_path = self._root / "project.json"
        self.docs_path = self._root / "docs.json"
        self.tiles_path = self._root / "tiles.json"
        self.labels_path = self._root / "labels.json"

        self.docs_dir = self._root / "documents"
        self.cache_dir = self._root / "cache"
        self.models_dir = self._root / "models"
        self.exports_dir = self._root / "exports"

        for d in [self.docs_dir, self.cache_dir, self.models_dir, self.exports_dir]:
            d.mkdir(parents=True, exist_ok=True)

    # @staticmethod  # removed; this is an instance method
    def _filter_polys_for_channel(self, polys, channel_id: str | None):
        """Return only polylines that belong to the given channel.
        Channel matching is name-based (pillar vs wall).
        """
        if channel_id is None:
            return polys
        cid = str(channel_id).lower()
        out = []
        for p in polys or []:
            n = (getattr(p, 'class_name', '') or '').lower()
            if 'pillar' in cid:
                if 'pillar' in n:
                    out.append(p)
            elif 'wall' in cid:
                if 'wall' in n:
                    out.append(p)
            else:
                if cid in n:
                    out.append(p)
        return out

    def create(root: str) -> "Project":
        p = Project(root)
        if p.meta_path.exists():
            raise RuntimeError("Project already exists in this folder (project.json found).")
        p._write_json(p.meta_path, {"version": 2, "classes": DEFAULT_CLASSES})
        p._write_json(p.docs_path, {"documents": []})
        p._write_json(p.tiles_path, {"tiles": []})
        p._write_json(p.labels_path, {"labels": {}})
        return p

    @staticmethod
    def load(root: str) -> "Project":
        p = Project(root)
        if not p.meta_path.exists():
            raise RuntimeError("Not a MineTrace project folder (project.json missing).")
        return p

    # ---------- Documents ----------
    def add_document(self, original_path: str) -> str:
        doc_id = f"DOC-{uuid.uuid4().hex[:8]}"
        src = Path(original_path)
        if not src.exists():
            raise FileNotFoundError(original_path)

        dst = self.docs_dir / f"{doc_id}{src.suffix.lower()}"
        shutil.copy2(src, dst)

        cache_path, kind = cache_document(dst, self.cache_dir, doc_id)

        docs = self._read_json(self.docs_path)["documents"]
        docs.append(asdict(DocumentRec(
            doc_id=doc_id,
            original_path=str(dst),
            cache_path=str(cache_path),
            kind=kind,
        )))
        self._write_json(self.docs_path, {"documents": docs})
        return doc_id

    def list_documents(self) -> list[DocumentRec]:
        raw = self._read_json(self.docs_path)["documents"]
        return [DocumentRec(**d) for d in raw]

    def get_document(self, doc_id: str) -> DocumentRec:
        for d in self.list_documents():
            if d.doc_id == doc_id:
                return d
        raise KeyError(doc_id)

    # ---------- Tiles ----------
    def add_suggested_tiles(self, doc_id: str, tiles: list[dict[str, Any]]) -> None:
        all_tiles = self._read_json(self.tiles_path)["tiles"]
        for t in tiles:
            tid = f"T-{uuid.uuid4().hex[:10]}"
            all_tiles.append(asdict(TileRec(
                tile_id=tid, doc_id=doc_id,
                x=int(t["x"]), y=int(t["y"]), w=int(t["w"]), h=int(t["h"]),
                score=float(t.get("score", 0.0)),
                status="suggested"
            )))
        self._write_json(self.tiles_path, {"tiles": all_tiles})

    def add_manual_tile(self, doc_id: str, x: int, y: int, w: int, h: int) -> None:
        all_tiles = self._read_json(self.tiles_path)["tiles"]
        tid = f"T-{uuid.uuid4().hex[:10]}"
        all_tiles.append(asdict(TileRec(
            tile_id=tid, doc_id=doc_id,
            x=int(x), y=int(y), w=int(w), h=int(h),
            score=1.0, status="suggested"
        )))
        self._write_json(self.tiles_path, {"tiles": all_tiles})

    def list_tiles(self, doc_id: str) -> list[TileRec]:
        raw = self._read_json(self.tiles_path)["tiles"]
        return [TileRec(**t) for t in raw if t["doc_id"] == doc_id]

    def clear_suggested_tiles_for_doc(self, doc_id: str) -> None:
        """Remove previously suggested tiles for this document, keeping accepted/rejected."""
        data = self._read_json(self.tiles_path)
        keep = []
        for t in data["tiles"]:
            if t["doc_id"] != doc_id:
                keep.append(t)
            else:
                if t.get("status") in ("accepted", "rejected"):
                    keep.append(t)
        data["tiles"] = keep
        self._write_json(self.tiles_path, data)


    def update_tile_status(self, tile_id: str, status: str) -> None:
        data = self._read_json(self.tiles_path)
        for t in data["tiles"]:
            if t["tile_id"] == tile_id:
                t["status"] = status
                self._write_json(self.tiles_path, data)
                return
        raise KeyError(tile_id)

    # ---------- Labels ----------
    def save_tile_labels(self, doc_id: str, tile_id: str, polylines: list[PolylineRec]) -> None:
        data = self._read_json(self.labels_path)
        labels = data["labels"]
        labels_key = f"{doc_id}:{tile_id}"
        labels[labels_key] = [asdict(p) for p in polylines]
        self._write_json(self.labels_path, {"labels": labels})
        self.update_tile_status(tile_id, "accepted")

    def get_tile_labels(self, doc_id: str, tile_id: str) -> list[PolylineRec]:
        data = self._read_json(self.labels_path)["labels"]
        key = f"{doc_id}:{tile_id}"
        if key not in data:
            return []
        return [PolylineRec(**p) for p in data[key]]

    def list_all_labels(self) -> dict[str, list[PolylineRec]]:
        data = self._read_json(self.labels_path)["labels"]
        return {k: [PolylineRec(**p) for p in v] for k, v in data.items()}

    def get_classes(self) -> list[dict[str, str]]:
        return self._read_json(self.meta_path)["classes"]

    # ---------- Training data ----------
    def ensure_training_data_from_labels(self, channel_id: str | None = None, data_root_override=None) -> None:
        from .rasterize import rasterize_tile_labels, render_label_overlay
        from .image_io import load_document_to_numpy
        from PIL import Image

        base_root = Path(data_root_override) if data_root_override is not None else Path(self._root)
        if channel_id:
            cid = str(channel_id)
            # If caller already passed a channel-specific root (e.g., .../pillars), avoid duplicating .../pillars/pillars
            if base_root.name.lower() != cid.lower():
                base_root = base_root / cid
        train_img_dir = base_root / "train" / "images"
        train_msk_dir = base_root / "train" / "masks"
        train_lbl_dir = base_root / "train" / "labels"

        # Fallback: if no labeled tiles exist yet, but the project folder contains legacy
        # crop pairs like "Training crop 1a.png" + "Training crop 1b.png", import them
        # into train/images + train/masks so training can start immediately.
        if not getattr(self, "labels", None):
            try:
                import numpy as np
                import re
                # from pathlib import Path  # moved to module scope
                from PIL import Image

                root = Path(self._root)
                # match: any filename ending with 'a.png' and having a corresponding 'b.png'
                a_files = sorted([p for p in root.glob("*.png") if re.search(r"(?:^|\s|_)\d+a\.png$", p.name, re.IGNORECASE) or p.name.lower().endswith("a.png")])
                pairs = []
                for a in a_files:
                    b = a.with_name(re.sub(r"a\.png$", "b.png", a.name, flags=re.IGNORECASE))
                    if b.exists():
                        pairs.append((a, b))

                if pairs:
                    train_img_dir.mkdir(parents=True, exist_ok=True)
                    train_msk_dir.mkdir(parents=True, exist_ok=True)

                    for i, (a, b) in enumerate(pairs, start=1):
                        img = Image.open(a).convert("RGB")
                        lab = Image.open(b).convert("RGB")
                        lab_np = np.array(lab)

                        # Pillars-only: treat "yellow" pixels as class 1 (foreground).
                        r, g, bb = lab_np[..., 0], lab_np[..., 1], lab_np[..., 2]
                        yellow = (r > 200) & (g > 200) & (bb < 160)

                        # Create an RGB mask with yellow strokes on black so the mask parser works.
                        msk_rgb = np.zeros_like(lab_np, dtype=np.uint8)
                        msk_rgb[yellow] = np.array([255, 255, 0], dtype=np.uint8)
                        msk_img = Image.fromarray(msk_rgb, mode="RGB")

                        out_stem = f"legacy_{i:04d}"
                        img.save(train_img_dir / f"{out_stem}.png")
                        msk_img.save(train_msk_dir / f"{out_stem}.png")
            except Exception:
                # If legacy import fails, training will fall back to labeled tiles (if any).
                pass
        train_img_dir.mkdir(parents=True, exist_ok=True)
        train_msk_dir.mkdir(parents=True, exist_ok=True)
        train_lbl_dir.mkdir(parents=True, exist_ok=True)

        labels = self.list_all_labels()
        tiles_data = self._read_json(self.tiles_path)["tiles"]
        tile_by_key = {(t["doc_id"], t["tile_id"]): TileRec(**t) for t in tiles_data}

        def _keep_poly(pl):
            if channel_id is None:
                return True
            n = (pl.class_name or "").lower()
            cid = str(channel_id).lower()
            if "pillar" in cid:
                return "pillar" in n
            if "wall" in cid:
                return "wall" in n
            # fallback: substring match
            return cid in n

        for key, polys in labels.items():
            polys = self._filter_polys_for_channel(polys, channel_id)
            if not polys:
                continue
            doc_id, tile_id = key.split(":")
            tile = tile_by_key.get((doc_id, tile_id))
            if tile is None:
                continue

            doc = self.get_document(doc_id)
            img = load_document_to_numpy(doc.cache_path)
            crop = img[tile.y:tile.y+tile.h, tile.x:tile.x+tile.w].copy()

            polys = [p for p in polys if _keep_poly(p)]
            if not polys:
                continue
            mask = rasterize_tile_labels(crop.shape[1], crop.shape[0], polys, self.get_classes())

            # Human-reference labeled overlay (raw + colored strokes)
            overlay = render_label_overlay(crop.shape[1], crop.shape[0], polys, self.get_classes())
            # Force channel display color so pillar labels are yellow and wall labels are cyan.
            try:
                import numpy as _np
                _m = (overlay.sum(axis=2) > 0)
                _cid = (str(channel_id).lower() if channel_id is not None else '')
                if 'wall' in _cid:
                    overlay[_m] = _np.array([0, 255, 255], dtype=_np.uint8)
                else:
                    overlay[_m] = _np.array([255, 255, 0], dtype=_np.uint8)
            except Exception:
                pass
            labeled = crop.copy()
            # alpha blend overlay onto crop
            import numpy as np
            alpha = (overlay.sum(axis=2) > 0).astype(np.float32)[..., None] * 0.85
            labeled = (labeled.astype(np.float32)*(1-alpha) + overlay.astype(np.float32)*alpha).astype(np.uint8)

            base = f"{doc_id}_{tile_id}"
            Image.fromarray(crop).save(train_img_dir / f"{base}.png")
            Image.fromarray(labeled).save(train_lbl_dir / f"{base}.png")
            # MineTrace training expects an RGB "overlay" mask where positive class is encoded
            # by yellow (pillars) and optionally cyan (walls). We can simply reuse the rendered
            # labeled overlay for the mask, since the parser detects stroke colors.
            Image.fromarray(overlay).save(train_msk_dir / f"{base}_mask.png")
            # Optional: raw class-id mask for debugging / future multi-class work
            try:
                import numpy as _np
                Image.fromarray(_np.asarray(mask).astype(_np.uint8), mode='L').save(train_msk_dir / f"{base}_mask_id.png")
            except Exception:
                pass

    def reset_training(self) -> None:
        if self.models_dir.exists():
            for p in self.models_dir.glob("*"):
                if p.is_file():
                    p.unlink()
        if self.exports_dir.exists():
            for p in self.exports_dir.rglob("*"):
                if p.is_file():
                    p.unlink()

    
    # ---------- Training set export/import ----------
    def export_training_set(self, zip_path: str) -> dict[str, int]:
        """
        Export a portable training set ZIP containing:
          - project.json (classes)
          - train/images/*.png
          - train/masks/*_mask.png (and *_mask_vis.png if present)
          - train/labels/*.png (optional; human reference)
          - manifest.json (version + class list + counts)

        This does NOT include full source documents.
        """
        from zipfile import ZipFile, ZIP_DEFLATED

        # Ensure train/ is up to date from labels (accepted tiles)
        self.ensure_training_data_from_labels()

        zpath = Path(zip_path)
        zpath.parent.mkdir(parents=True, exist_ok=True)

        train_img_dir = self._root / "train" / "images"
        train_img_dir = self._root / "train" / "images"
        train_msk_dir = self._root / "train" / "masks"
        train_lbl_dir = self._root / "train" / "labels"
        msks = sorted(train_msk_dir.glob("*.png")) if train_msk_dir.exists() else []
        lbls = sorted(train_lbl_dir.glob("*.png")) if train_lbl_dir.exists() else []

        classes = self.get_classes()
        manifest = {
            "format": "MineTraceTrainingSet",
            "exporter_project_version": self._read_json(self.meta_path).get("version", None),
            "classes": [c["name"] for c in classes],
            "counts": {"images": len(imgs), "masks": len(msks), "labels": len(lbls)},
        }

        with ZipFile(zpath, "w", compression=ZIP_DEFLATED) as z:
            # metadata
            z.write(self.meta_path, arcname="project.json")
            z.writestr("manifest.json", json.dumps(manifest, indent=2))
            # data
            for p in imgs:
                z.write(p, arcname=f"train/images/{p.name}")
            for p in msks:
                z.write(p, arcname=f"train/masks/{p.name}")
            for p in lbls:
                z.write(p, arcname=f"train/labels/{p.name}")

        return {"images": len(imgs), "masks": len(msks), "labels": len(lbls)}

    def import_training_set(self, zip_path: str) -> dict[str, int]:
        """
        Import a training set ZIP into this project.

        Safety rules:
          - Requires class names to match (same order) for the classes present in the ZIP.
          - Copies files into train/images, train/masks (and optional train/labels) without overwriting existing files
            (adds suffix if collision).
        """
        from zipfile import ZipFile
        import tempfile

        zpath = Path(zip_path)
        if not zpath.exists():
            raise FileNotFoundError(zip_path)

        # Read manifest + exported project.json if present
        with ZipFile(zpath, "r") as z:
            names = set(z.namelist())
            if "manifest.json" not in names:
                raise RuntimeError("Not a MineTrace training set (manifest.json missing).")
            manifest = json.loads(z.read("manifest.json").decode("utf-8"))
            if manifest.get("format") != "MineTraceTrainingSet":
                raise RuntimeError("Unsupported training set format.")

            exported_classes = manifest.get("classes", [])
            my_classes = [c["name"] for c in self.get_classes()]
            # Must match order for the imported classes
            if my_classes[:len(exported_classes)] != exported_classes:
                raise RuntimeError(
                    "Class mismatch. This project classes must start with: "
                    + ", ".join(exported_classes)
                )

            # Extract train files to temp then copy
            with tempfile.TemporaryDirectory() as td:
                td = Path(td)
                z.extractall(td)

                src_img = td / "train" / "images"
                src_msk = td / "train" / "masks"
                src_lbl = td / "train" / "labels"

                dst_img = self._root / "train" / "images"
                dst_msk = self._root / "train" / "masks"
                dst_lbl = self._root / "train" / "labels"
                dst_img.mkdir(parents=True, exist_ok=True)
                dst_msk.mkdir(parents=True, exist_ok=True)
                dst_lbl.mkdir(parents=True, exist_ok=True)

                def safe_copy(src: Path, dst_dir: Path) -> int:
                    if not src.exists():
                        return 0
                    n = 0
                    for f in src.glob("*.png"):
                        out = dst_dir / f.name
                        if out.exists():
                            stem, suf = out.stem, out.suffix
                            k = 2
                            while True:
                                cand = dst_dir / f"{stem}_imp{k}{suf}"
                                if not cand.exists():
                                    out = cand
                                    break
                                k += 1
                        shutil.copy2(f, out)
                        n += 1
                    return n

                ni = safe_copy(src_img, dst_img)
                nm = safe_copy(src_msk, dst_msk)
                nl = safe_copy(src_lbl, dst_lbl)

        return {"images": ni, "masks": nm, "labels": nl}
# ---------- IO ----------
    @staticmethod
    def _read_json(path: Path) -> dict[str, Any]:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    @staticmethod
    def _write_json(path: Path, data: dict[str, Any]) -> None:
        tmp = path.with_suffix(path.suffix + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        tmp.replace(path)