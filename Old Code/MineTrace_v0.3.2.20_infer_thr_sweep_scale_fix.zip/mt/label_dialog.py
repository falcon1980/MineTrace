from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QComboBox, QSpinBox,    QLabel, QMessageBox, QFrame, QSizePolicy
)

from .project import Project, TileRec
from .polyline_canvas import PolylineCanvas


class LabelTileDialog(QDialog):
    def __init__(self, project: Project, doc_id: str, tile: TileRec, tile_image, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Label Tile {tile.tile_id}")
        self.resize(1120, 820)

        self.project = project
        self.doc_id = doc_id
        self.tile = tile
        self.tile_image = tile_image

        # Canvas
        self.canvas = PolylineCanvas(tile_image)
        existing = project.get_tile_labels(doc_id, tile.tile_id)
        self.canvas.load_polylines(existing)

        # Root layout: left help panel + canvas, then bottom bar
        root = QVBoxLayout(self)

        top = QHBoxLayout()
        root.addLayout(top)

        # ---- Left panel (controls/help) ----
        left = QFrame()
        left.setFrameShape(QFrame.StyledPanel)
        left.setFixedWidth(260)
        left_layout = QVBoxLayout(left)

        title = QLabel("Controls")
        title.setStyleSheet("font-weight: 600; font-size: 14px;")
        left_layout.addWidget(title)

        help_txt = QLabel(
            "Mouse:\n"
            " • Left-click: add point\n"
            " • Right-click: finish polyline\n\n"
            "Tips:\n"
            " • Use Class + Thickness below\n"
            " • Undo/Redo work per action\n\n"
            "Buttons:\n"
            " • Reject Tile\n"
            " • Save & Close\n"
        )
        help_txt.setWordWrap(True)
        help_txt.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        left_layout.addWidget(help_txt)

        # Class / thickness controls in the left panel
        left_layout.addWidget(QLabel("Class:"))
        self.cmb = QComboBox()
        for c in self.project.get_classes():
            self.cmb.addItem(c["name"])
        self.cmb.currentTextChanged.connect(self.canvas.set_active_class)
        left_layout.addWidget(self.cmb)

        left_layout.addWidget(QLabel("Thickness:"))
        self.sp_thick = QSpinBox()
        self.sp_thick.setRange(1, 25)
        self.sp_thick.setValue(3)
        self.sp_thick.valueChanged.connect(self.canvas.set_active_thickness)
        left_layout.addWidget(self.sp_thick)

        left_layout.addStretch(1)

        top.addWidget(left)

        # ---- Canvas ----
        top.addWidget(self.canvas, 1)

        # ---- Bottom bar ----
        bar = QHBoxLayout()
        root.addLayout(bar)

        btn_undo = QPushButton("Undo")
        btn_redo = QPushButton("Redo")
        btn_reject = QPushButton("Reject Tile")
        btn_save = QPushButton("Save & Close")

        btn_undo.clicked.connect(self.canvas.undo)
        btn_redo.clicked.connect(self.canvas.redo)

        # Keyboard shortcuts
        QShortcut(QKeySequence.Undo, self, activated=self.canvas.undo)
        QShortcut(QKeySequence.Redo, self, activated=self.canvas.redo)
        QShortcut(QKeySequence("Ctrl+Shift+Z"), self, activated=self.canvas.redo)
        QShortcut(QKeySequence("Escape"), self, activated=self.canvas.abort_current)
        btn_reject.clicked.connect(self.reject_tile)
        btn_save.clicked.connect(self.save_and_close)

        bar.addWidget(btn_undo)
        bar.addWidget(btn_redo)
        bar.addStretch(1)
        bar.addWidget(btn_reject)
        bar.addWidget(btn_save)

        self.canvas.set_active_class(self.cmb.currentText())
        self.canvas.set_active_thickness(self.sp_thick.value())

    def reject_tile(self):
        self.project.update_tile_status(self.tile.tile_id, "rejected")
        self.accept()

    def save_and_close(self):
        polylines = self.canvas.export_polylines()
        if len(polylines) == 0:
            ok = QMessageBox.question(self, "No Labels", "No polylines drawn. Mark tile as rejected?")
            if ok == QMessageBox.Yes:
                self.project.update_tile_status(self.tile.tile_id, "rejected")
            self.accept()
            return
        self.project.save_tile_labels(self.doc_id, self.tile.tile_id, polylines)
        self.project.update_tile_status(self.tile.tile_id, "accepted")
        self.accept()
