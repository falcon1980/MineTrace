
import numpy as np
from PySide6.QtCore import Qt, QRect
from PySide6.QtGui import QImage, QPixmap, QPainter, QPen
from PySide6.QtWidgets import QLabel

from PIL import Image


class ImageViewer(QLabel):
    """
    Viewer with fit-to-window drawing and a simple manual selection rectangle.
    Adds overlay support for prediction maps (0..255 grayscale).
    """
    def __init__(self):
        super().__init__()
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumSize(900, 700)
        self._img = None  # numpy
        self._pix = None  # QPixmap

        self._start = None
        self._rect = None

        # overlays
        self._ov_pillars = None  # uint8 HxW
        self._ov_walls = None
        self.overlay_enabled = {"pillars": True, "walls": True}
        self.overlay_threshold = {"pillars": 140, "walls": 140}

    def set_image(self, img_rgb: np.ndarray):
        self._img = img_rgb
        h, w = img_rgb.shape[:2]
        qimg = QImage(img_rgb.data, w, h, 3*w, QImage.Format_RGB888)
        self._pix = QPixmap.fromImage(qimg)
        self._rect = None
        self.update()

    def set_overlays(self, pillars_path: str, walls_path: str):
        p = np.array(Image.open(pillars_path).convert("L"), dtype=np.uint8)
        w = np.array(Image.open(walls_path).convert("L"), dtype=np.uint8)
        self._ov_pillars = p
        self._ov_walls = w
        self.update()

    def clear_overlays(self):
        self._ov_pillars = None
        self._ov_walls = None
        self.update()

    def paintEvent(self, e):
        super().paintEvent(e)
        if not self._pix:
            return
        painter = QPainter(self)
        target = self.rect()
        scaled = self._pix.scaled(target.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        x0 = (target.width() - scaled.width()) // 2
        y0 = (target.height() - scaled.height()) // 2
        painter.drawPixmap(x0, y0, scaled)

        # overlays
        if self._img is not None and self._ov_pillars is not None:
            ih, iw = self._img.shape[:2]
            sx = scaled.width() / iw
            sy = scaled.height() / ih

            def draw_overlay(ov, kind):
                if ov is None:
                    return
                if not self.overlay_enabled.get(kind, True):
                    return
                thr = int(self.overlay_threshold.get(kind, 140))
                # make ARGB overlay image
                # Pillars: yellow, Walls: cyan-ish
                if kind == "pillars":
                    color = (255, 255, 0)  # RGB
                else:
                    color = (0, 255, 255)

                mask = (ov >= thr).astype(np.uint8) * 160  # alpha
                rgba = np.zeros((ih, iw, 4), dtype=np.uint8)
                rgba[..., 0] = color[0]
                rgba[..., 1] = color[1]
                rgba[..., 2] = color[2]
                rgba[..., 3] = mask

                qimg = QImage(rgba.data, iw, ih, 4*iw, QImage.Format_RGBA8888)
                pix = QPixmap.fromImage(qimg)
                pix_s = pix.scaled(scaled.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
                painter.drawPixmap(x0, y0, pix_s)

            draw_overlay(self._ov_pillars, "pillars")
            draw_overlay(self._ov_walls, "walls")

        # selection rect
        if self._rect is not None:
            pen = QPen(Qt.red, 2, Qt.DashLine)
            painter.setPen(pen)
            r = self._widget_rect_from_image_rect(self._rect, scaled, x0, y0)
            painter.drawRect(r)

    def mousePressEvent(self, ev):
        if ev.button() == Qt.LeftButton and self._pix:
            self._start = ev.pos()
            self._rect = None
            self.update()

    def mouseMoveEvent(self, ev):
        if self._start is None:
            return
        end = ev.pos()
        r = QRect(self._start, end).normalized()
        self._rect = self._image_rect_from_widget_rect(r)
        self.update()

    def mouseReleaseEvent(self, ev):
        self._start = None
        self.update()

    def get_manual_rect(self):
        if self._rect is None:
            return None
        x, y, w, h = self._rect
        return (x, y, w, h)

    def _image_rect_from_widget_rect(self, widget_rect: QRect):
        if self._img is None or self._pix is None:
            return None
        ih, iw = self._img.shape[:2]
        target = self.rect()
        scaled = self._pix.scaled(target.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        x0 = (target.width() - scaled.width()) // 2
        y0 = (target.height() - scaled.height()) // 2

        r = widget_rect.intersected(QRect(x0, y0, scaled.width(), scaled.height()))
        if r.width() <= 2 or r.height() <= 2:
            return None

        sx = iw / scaled.width()
        sy = ih / scaled.height()
        ix = int((r.x() - x0) * sx)
        iy = int((r.y() - y0) * sy)
        iw2 = int(r.width() * sx)
        ih2 = int(r.height() * sy)
        return (ix, iy, iw2, ih2)

    def _widget_rect_from_image_rect(self, image_rect, scaled_pix, x0, y0):
        ix, iy, iw2, ih2 = image_rect
        ih, iw = self._img.shape[:2]
        sx = scaled_pix.width() / iw
        sy = scaled_pix.height() / ih
        x = int(ix * sx) + x0
        y = int(iy * sy) + y0
        w = int(iw2 * sx)
        h = int(ih2 * sy)
        return QRect(x, y, w, h)
