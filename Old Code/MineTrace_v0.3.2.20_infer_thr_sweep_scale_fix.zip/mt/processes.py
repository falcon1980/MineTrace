
import sys
from pathlib import Path
from PySide6.QtCore import QObject, QProcess, Signal, QProcessEnvironment
from PySide6.QtWidgets import QMessageBox


class TrainProcess(QObject):
    finished = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.proc = QProcess(parent)
        self.proc.readyReadStandardOutput.connect(self._stdout)
        self.proc.readyReadStandardError.connect(self._stderr)
        self.proc.finished.connect(self._finished)

    def start(self, project_root: str, env_overrides: dict | None = None):
        root = str(Path(project_root).resolve())
        python = sys.executable
        env = QProcessEnvironment.systemEnvironment()
        env.insert("PYTHONUNBUFFERED", "1")
        if env_overrides:
            for k, v in env_overrides.items():
                env.insert(str(k), str(v))
        self.proc.setProcessEnvironment(env)
        self.proc.start(python, ["-u", "-m", "mt.train_worker", root])

    def _stdout(self):
        data = self.proc.readAllStandardOutput().data().decode("utf-8", errors="ignore")
        if data.strip():
            print(data, end="")

    def _stderr(self):
        data = self.proc.readAllStandardError().data().decode("utf-8", errors="ignore")
        if data.strip():
            print(data, end="")

    def _finished(self, code, status):
        QMessageBox.information(None, "Training", f"Training finished (code={code}).")
        self.finished.emit()


class InferProcess(QObject):
    finished = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.proc = QProcess(parent)
        self.proc.readyReadStandardOutput.connect(self._stdout)
        self.proc.readyReadStandardError.connect(self._stderr)
        self.proc.finished.connect(self._finished)

    def start(self, project_root: str, doc_id: str, thr_pillars: int = 140, thr_walls: int = 140, alpha: int = 160, tile_size: int = 128, overlap: float = 0.50, env_overrides: dict | None = None):
        python = sys.executable
        env = QProcessEnvironment.systemEnvironment()
        env.insert("PYTHONUNBUFFERED", "1")
        if env_overrides:
            for k, v in env_overrides.items():
                env.insert(str(k), str(v))
        self.proc.setProcessEnvironment(env)
        self.proc.start(python, ["-u", "-m", "mt.infer_worker", str(Path(project_root).resolve()), doc_id, str(int(thr_pillars)), str(int(thr_walls)), str(int(alpha)), str(int(tile_size)), str(float(overlap))])

    def _stdout(self):
        data = self.proc.readAllStandardOutput().data().decode("utf-8", errors="ignore")
        if data.strip():
            print(data, end="")

    def _stderr(self):
        data = self.proc.readAllStandardError().data().decode("utf-8", errors="ignore")
        if data.strip():
            print(data, end="")

    def _finished(self, code, status):
        QMessageBox.information(None, "Predict", f"Prediction finished (code={code}).")
        self.finished.emit()