
from pathlib import Path
import shutil

def cache_document(src_path: Path, cache_dir: Path, doc_id: str, pdf_dpi: int = 300) -> tuple[Path, str]:
    ext = src_path.suffix.lower()
    if ext == ".pdf":
        try:
            import fitz  # PyMuPDF
        except Exception as e:
            raise RuntimeError("PDF support requires pymupdf. Install: pip install pymupdf") from e

        doc = fitz.open(str(src_path))
        if doc.page_count < 1:
            raise RuntimeError("PDF has no pages.")
        page = doc.load_page(0)

        zoom = pdf_dpi / 72.0
        mat = fitz.Matrix(zoom, zoom)
        pix = page.get_pixmap(matrix=mat, alpha=False)

        out = cache_dir / f"{doc_id}_page1.png"
        pix.save(str(out))
        return out, "pdf"

    out = cache_dir / f"{doc_id}{ext}"
    shutil.copy2(src_path, out)
    return out, "image"
