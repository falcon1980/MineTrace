
import numpy as np
import cv2

def clamp_tile_size(w: int, h: int, max_tile: int) -> int:
    size = min(max_tile, w, h)
    for s in [512, 448, 384, 320, 256, 224, 192, 160, 128]:
        if size >= s:
            return s
    return 128

def suggest_tiles(img_rgb: np.ndarray, tile_size: int, overlap: float, top_k: int) -> list[dict]:
    h, w = img_rgb.shape[:2]
    step = max(32, int(tile_size * (1.0 - overlap)))
    gray = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2GRAY)
    edges = cv2.Canny(gray, 80, 160)

    candidates = []
    for y in range(0, max(1, h - tile_size + 1), step):
        for x in range(0, max(1, w - tile_size + 1), step):
            tile = edges[y:y+tile_size, x:x+tile_size]
            score = float(tile.mean() / 255.0)
            if score < 0.01:
                continue
            candidates.append({"x": x, "y": y, "w": tile_size, "h": tile_size, "score": score})

    candidates.sort(key=lambda t: t["score"], reverse=True)
    return candidates[:top_k]
