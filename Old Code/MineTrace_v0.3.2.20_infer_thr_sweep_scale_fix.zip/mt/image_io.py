
from pathlib import Path
import numpy as np

def load_document_to_numpy(path: str) -> np.ndarray:
    p = Path(path)
    ext = p.suffix.lower()

    if ext in [".tif", ".tiff"]:
        import tifffile as tiff
        arr = tiff.imread(str(p))
        arr = _ensure_rgb(arr)
        return arr

    from PIL import Image
    img = Image.open(str(p)).convert("RGB")
    return np.array(img, dtype=np.uint8)

def _ensure_rgb(arr: np.ndarray) -> np.ndarray:
    if arr.ndim == 2:
        arr = np.stack([arr, arr, arr], axis=-1)
    elif arr.ndim == 3 and arr.shape[2] == 4:
        arr = arr[:, :, :3]
    elif arr.ndim == 3 and arr.shape[2] == 3:
        pass
    else:
        if arr.ndim == 3:
            arr = arr[:, :, :3]
        else:
            raise RuntimeError(f"Unsupported TIFF shape: {arr.shape}")
    if arr.dtype != np.uint8:
        arr = arr.astype(np.float32)
        arr = (255 * (arr - arr.min()) / (arr.max() - arr.min() + 1e-6)).astype(np.uint8)
    return arr
