
import sys
import os
from pathlib import Path
import glob
import random
import re

# --- Persistent data roots (optional) ---
def _get_env_path(name, default=None):
    v = os.environ.get(name, default)
    if v is None:
        return None
    v = str(v).strip().strip('"').strip("'")
    return v

def _resolve_paths(project_root):
    """Return (data_root, model_root, output_root)."""
    data_root = _get_env_path("MT_DATA_ROOT")
    model_root = _get_env_path("MT_MODEL_ROOT")
    output_root = _get_env_path("MT_OUTPUT_ROOT")
    if not data_root:
        data_root = project_root
    if not model_root:
        model_root = project_root
    if not output_root:
        output_root = project_root
    ch = _get_env_path("MT_CHANNEL")
    if ch:
        data_root = str(Path(data_root) / ch)
        model_root = str(Path(model_root) / ch)
        output_root = str(Path(output_root) / ch)
    return data_root, model_root, output_root

import numpy as np
from PIL import Image

# Torch imports (needed by model + dataloader)
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader


def _coerce_state_dict_n_classes(sd: dict, n_classes: int) -> dict:
    """Slice checkpoint head weights/bias to match n_classes.

    We occasionally change the number of output channels (e.g., pillars-only vs hybrid
    fill+edge). Older checkpoints may have a classifier head with a different number of
    output channels. This helper makes the checkpoint compatible by slicing the final
    layer weights and bias.
    """
    if not isinstance(sd, dict):
        return sd
    for w_key, b_key in [("out.weight", "out.bias"), ("out.conv.weight", "out.conv.bias")]:
        if w_key in sd and hasattr(sd[w_key], "shape") and len(getattr(sd[w_key], "shape")) == 4:
            if int(sd[w_key].shape[0]) != int(n_classes):
                sd[w_key] = sd[w_key][:n_classes].contiguous()
            if b_key in sd and hasattr(sd[b_key], "shape") and len(getattr(sd[b_key], "shape")) == 1:
                if int(sd[b_key].shape[0]) != int(n_classes):
                    sd[b_key] = sd[b_key][:n_classes].contiguous()
    return sd

def _binary_dilate(mask: np.ndarray, r: int = 1) -> np.ndarray:
    """Binary dilation using a (2r+1)x(2r+1) square structuring element (pure numpy)."""
    if r <= 0:
        return mask.astype(bool)
    m = mask.astype(bool)
    pad = r
    p = np.pad(m, ((pad, pad), (pad, pad)), mode="constant", constant_values=False)
    out = np.zeros_like(m, dtype=bool)
    # sliding window max
    for dy in range(-r, r + 1):
        ys = pad + dy
        ye = ys + m.shape[0]
        for dx in range(-r, r + 1):
            xs = pad + dx
            xe = xs + m.shape[1]
            out |= p[ys:ye, xs:xe]
    return out

def _binary_erode(mask: np.ndarray, r: int = 1) -> np.ndarray:
    """Binary erosion using a (2r+1)x(2r+1) square structuring element (pure numpy)."""
    if r <= 0:
        return mask.astype(bool)
    m = mask.astype(bool)
    pad = r
    p = np.pad(m, ((pad, pad), (pad, pad)), mode="constant", constant_values=True)
    out = np.ones_like(m, dtype=bool)
    # sliding window min
    for dy in range(-r, r + 1):
        ys = pad + dy
        ye = ys + m.shape[0]
        for dx in range(-r, r + 1):
            xs = pad + dx
            xe = xs + m.shape[1]
            out &= p[ys:ye, xs:xe]
    return out

def _binary_edge(mask: np.ndarray, r: int = 1) -> np.ndarray:
    """Return a 1px-ish boundary (mask AND NOT erode(mask))."""
    m = mask.astype(bool)
    e = m & (~_binary_erode(m, r=r))
    return e

def _render_blue_overlay(img_rgb_u8: np.ndarray, edge_mask_bool: np.ndarray, alpha: float = 0.55) -> np.ndarray:
    """Overlay blue on img where edge_mask_bool is True."""
    base = img_rgb_u8.copy()
    blue = np.zeros_like(base)
    blue[..., 2] = 255
    m = edge_mask_bool.astype(bool)
    base[m] = (base[m] * (1 - alpha) + blue[m] * alpha).astype(np.uint8)
    return base


def pad_or_crop(img: np.ndarray, target_h: int, target_w: int, fill: int = 255) -> np.ndarray:
    """Pad or center-crop a HxWxC (or HxW) numpy array to (target_h, target_w).
    For map imagery we pad with white (255) by default; for masks pass fill=0."""
    if img.ndim == 2:
        h, w = img.shape
        c = None
    else:
        h, w, c = img.shape
    # Crop (center)
    if h > target_h:
        top = (h - target_h) // 2
        img = img[top:top+target_h, ...]
        h = target_h
    if w > target_w:
        left = (w - target_w) // 2
        img = img[:, left:left+target_w, ...]
        w = target_w
    # Pad
    pad_h = max(0, target_h - h)
    pad_w = max(0, target_w - w)
    if pad_h or pad_w:
        top = pad_h // 2
        bottom = pad_h - top
        left = pad_w // 2
        right = pad_w - left
        if img.ndim == 2:
            img = np.pad(img, ((top, bottom), (left, right)), mode='constant', constant_values=fill)
        else:
            img = np.pad(img, ((top, bottom), (left, right), (0,0)), mode='constant', constant_values=fill)
    return img


# --- Auto-import helpers (for legacy training crops dropped in the project folder) ---
def _autofind_legacy_pairs(project_root: Path):
    """Find (image, mask) pairs in/near the project root that follow *a.png/*b.png naming."""
    pairs = []
    if not project_root.exists():
        return pairs
    candidates = list(project_root.glob("*.png")) + list(project_root.glob("*/*.png"))
    by_name = {c.name.lower(): c for c in candidates}
    for c in candidates:
        low = c.name.lower()
        if not low.endswith("a.png"):
            continue
        mask_name = c.name[:-5] + "b.png"
        m = by_name.get(mask_name.lower())
        if m is None:
            continue
        pairs.append((c, m))
    pairs.sort(key=lambda t: t[0].name.lower())
    return pairs


def _ensure_training_dirs(project_root: Path):
    # project_root is the resolved data_root (or local project root in legacy mode)
    img_dir = project_root / "train" / "images"
    msk_dir = project_root / "train" / "masks"
    print(f"[train] train_images_dir={img_dir}")
    print(f"[train] train_masks_dir={msk_dir}")
    try:
        n_img = len(list(img_dir.glob('*.png')))
        n_msk = len(list(msk_dir.glob('*.png')))
        print(f"[train] found training images={n_img} masks={n_msk}")
    except Exception as e:
        print(f"[train] WARN could not count training files: {e}")
    img_dir.mkdir(parents=True, exist_ok=True)
    msk_dir.mkdir(parents=True, exist_ok=True)
    return img_dir, msk_dir


def _auto_import_legacy_training(project_root: Path) -> int:
    """If train/images is empty, import any legacy *a/*b PNG pairs into train/images+masks."""
    img_dir, msk_dir = _ensure_training_dirs(project_root)
    existing = list(img_dir.glob("*.png")) + list(img_dir.glob("*.jpg")) + list(img_dir.glob("*.jpeg"))
    if existing:
        return 0

    pairs = _autofind_legacy_pairs(project_root)
    pairs = [pm for pm in pairs if "check" not in pm[0].name.lower()]
    imported = 0
    import shutil
    for img_path, mask_path in pairs:
        stem = img_path.stem
        out_img = img_dir / f"legacy_{stem}.png"
        out_msk = msk_dir / f"legacy_{stem}.png"
        try:
            shutil.copy2(img_path, out_img)
            shutil.copy2(mask_path, out_msk)
            imported += 1
        except Exception:
            pass
    return imported


def _find_check_pair(project_root: Path):
    pairs = _autofind_legacy_pairs(project_root)
    check_pairs = [pm for pm in pairs if "check" in pm[0].name.lower()]
    if not check_pairs:
        return None
    for img_path, mask_path in check_pairs:
        if img_path.name.lower().startswith("check 1") and img_path.name.lower().endswith("a.png"):
            return (img_path, mask_path)
    return check_pairs[0]

def _mask_to_classes(mask_img, n_classes: int) -> np.ndarray:
    """Convert a colored overlay mask into class indices.

    Supports PIL.Image.Image or a numpy array.

    For pillars-only mode (n_classes==2): class 1 == yellow strokes.
    For legacy pillars+walls (n_classes==3): class 1 == yellow, class 2 == cyan.
    """
    if isinstance(mask_img, Image.Image):
        rgb = np.array(mask_img.convert('RGB'))
    else:
        rgb = np.asarray(mask_img)
        # If a 2D array is provided, assume it already contains class ids.
        if rgb.ndim == 2:
            y = rgb.astype(np.int64)
            # Clamp to valid range to avoid CUDA NLLLoss asserts.
            y = np.clip(y, 0, n_classes - 1)
            return y
        # Some readers may return RGBA
        if rgb.ndim == 3 and rgb.shape[2] == 4:
            rgb = rgb[..., :3]

    r = rgb[..., 0]
    g = rgb[..., 1]
    b = rgb[..., 2]

    # Detect the label strokes drawn on top of the base map.
    is_yellow = (r > 200) & (g > 200) & (b < 160)
    is_cyan = (g > 180) & (b > 180) & (r < 140)

    y = np.zeros((rgb.shape[0], rgb.shape[1]), dtype=np.int64)

    if n_classes == 2:
        pos = (os.environ.get('MT_POS_COLOR','yellow') or 'yellow').lower()
        if pos.startswith('c'):
            y[is_cyan] = 1
        else:
            y[is_yellow] = 1
    elif n_classes >= 3:
        y[is_yellow] = 1
        y[is_cyan] = 2

    return y

def line_emphasis(img_rgb: np.ndarray) -> np.ndarray:
    x = img_rgb.astype(np.float32) / 255.0
    gray = (0.299 * x[..., 0] + 0.587 * x[..., 1] + 0.114 * x[..., 2])
    boosted = np.clip((1.0 - gray) * 1.5, 0.0, 1.0)
    x[..., 0] = np.clip(x[..., 0] * 0.6 + boosted * 0.4, 0, 1)
    x[..., 1] = np.clip(x[..., 1] * 0.6 + boosted * 0.4, 0, 1)
    x[..., 2] = np.clip(x[..., 2] * 0.6 + boosted * 0.4, 0, 1)
    return (x * 255.0).astype(np.uint8)




def _cyan_ignore_mask(mask_img) -> np.ndarray:
    """Return a boolean mask of pixels that are marked as cyan/turquoise wall annotations.

    This is used to *ignore* those pixels during training/eval in pillars-only mode,
    so wall labels don't act as negative examples.
    """
    if isinstance(mask_img, Image.Image):
        rgb = np.array(mask_img.convert('RGB'))
    else:
        rgb = np.asarray(mask_img)
        if rgb.ndim == 2:
            # no color info; nothing to ignore
            return np.zeros_like(rgb, dtype=bool)
        if rgb.ndim == 3 and rgb.shape[2] == 4:
            rgb = rgb[..., :3]
    r = rgb[..., 0]
    g = rgb[..., 1]
    b = rgb[..., 2]
    # Same cyan detector as _mask_to_classes
    is_cyan = (g > 180) & (b > 180) & (r < 140)
    return is_cyan


def random_augment(img: np.ndarray, mask: np.ndarray, ignore: np.ndarray | None = None):
    if random.random() < 0.5:
        img = np.flip(img, axis=1).copy()
        mask = np.flip(mask, axis=1).copy()
        if ignore is not None:
            ignore = np.flip(ignore, axis=1).copy()
    if random.random() < 0.5:
        img = np.flip(img, axis=0).copy()
        mask = np.flip(mask, axis=0).copy()
        if ignore is not None:
            ignore = np.flip(ignore, axis=0).copy()

    if random.random() < 0.7:
        a = 0.9 + 0.2 * random.random()
        b = (-15 + 30 * random.random())
        img = np.clip(img.astype(np.float32) * a + b, 0, 255).astype(np.uint8)

    # reduce chance of learning "color symbol == class"
    if random.random() < 0.5:
        gray = (0.299*img[...,0] + 0.587*img[...,1] + 0.114*img[...,2]).astype(np.uint8)
        img = np.stack([gray, gray, gray], axis=-1)

    return (img, mask, ignore) if ignore is not None else (img, mask)


class TileDataset(Dataset):
    def __init__(self, img_dir: str, msk_dir: str, size: int = 300, n_classes: int = 3):
        self.img_dir = Path(img_dir)
        self.msk_dir = Path(msk_dir)
        self.size = int(size)
        self.n_classes = int(n_classes)

        imgs = {p.stem: p for p in self.img_dir.glob("*.png")}
        # allow jpg/jpeg/tif too
        for ext in ("*.jpg", "*.jpeg", "*.tif", "*.tiff"):
            for p in self.img_dir.glob(ext):
                imgs.setdefault(p.stem, p)

        # Masks can be saved as either:
        #   <stem>.png          (legacy)
        #   <stem>_mask.png     (MineTrace UI)
        # Normalize keys so both forms match the corresponding image stem.
        msks = {}
        for p in self.msk_dir.glob("*.png"):
            k = p.stem
            if k.endswith("_mask"):
                k = k[:-5]
            msks[k] = p
        for ext in ("*.jpg", "*.jpeg", "*.tif", "*.tiff"):
            for p in self.msk_dir.glob(ext):
                msks.setdefault(p.stem, p)

        pairs = []
        for stem, ip in imgs.items():
            # candidate mask stems
            candidates = [stem, f"{stem}_mask", f"{stem}-mask"]
            if stem.endswith('a'):
                candidates.append(stem[:-1] + 'b')
                candidates.append(stem[:-1] + 'b_mask')
                candidates.append(stem[:-1] + 'b-mask')
            # also handle ... 1a -> ... 1b even if stem doesn't strictly end with 'a' (rare)
            if re.search(r"a$", stem):
                candidates.append(re.sub(r"a$", 'b', stem))
            mp = None
            for c in candidates:
                # normalize _mask suffix in dict
                cc = c
                if cc.endswith('_mask'):
                    cc = cc[:-5]
                if cc in msks:
                    mp = msks[cc]
                    break
            if mp is None:
                continue
            pairs.append((ip, mp))
        self.pairs = pairs
        if len(self.pairs) == 0:
            print(f"[train] Found 0 image/mask pairs in {self.img_dir} and {self.msk_dir}.")

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx: int):
        ip, mp = self.pairs[idx]
        img = np.array(Image.open(ip).convert("RGB"), dtype=np.uint8)
        mask_img_pil = Image.open(mp)
        mask = _mask_to_classes(mask_img_pil, self.n_classes)
        ignore_cyan = bool(int(os.environ.get('MT_IGNORE_CYAN', '1')))
        ignore = _cyan_ignore_mask(mask_img_pil) if ignore_cyan else np.zeros((mask.shape[0], mask.shape[1]), dtype=bool)

        # If mask came from a different size, force match
        if mask.shape[:2] != img.shape[:2]:
            mask = np.array(Image.fromarray(mask).resize((img.shape[1], img.shape[0]), resample=Image.NEAREST), dtype=np.uint8)

        aug = random_augment(img, mask, ignore)
        if len(aug) == 3:
            img, mask, ignore = aug
        else:
            img, mask = aug

        # pad/crop to size
        img = pad_or_crop(img, self.size, self.size, fill=255)
        mask = pad_or_crop(mask, self.size, self.size, fill=0)
        ignore = pad_or_crop(ignore.astype(np.uint8), self.size, self.size, fill=0).astype(bool)

        x = torch.from_numpy(img).permute(2, 0, 1).float() / 255.0
        y = torch.from_numpy(mask.astype(np.int64))
        ig = torch.from_numpy(ignore.astype(np.bool_))
        return x, y, ig


class TinyUNet(nn.Module):
    def __init__(self, n_classes: int):
        super().__init__()
        self.down1 = ConvBNReLU(3, 32)
        self.pool1 = nn.MaxPool2d(2)
        self.down2 = ConvBNReLU(32, 64)
        self.pool2 = nn.MaxPool2d(2)

        self.mid = ConvBNReLU(64, 96)

        self.up2 = nn.ConvTranspose2d(96, 64, 2, stride=2)
        self.conv2 = ConvBNReLU(64 + 64, 64)
        self.up1 = nn.ConvTranspose2d(64, 32, 2, stride=2)
        self.conv1 = ConvBNReLU(32 + 32, 32)

        self.head = nn.Conv2d(32, n_classes, 1)

    def forward(self, x):
        d1 = self.down1(x)
        p1 = self.pool1(d1)
        d2 = self.down2(p1)
        p2 = self.pool2(d2)
        m = self.mid(p2)
        u2 = self.up2(m)
        c2 = self.conv2(torch.cat([u2, d2], dim=1))
        u1 = self.up1(c2)
        c1 = self.conv1(torch.cat([u1, d1], dim=1))
        return self.head(c1)


class ConvBNReLU(nn.Module):
    def __init__(self, cin, cout):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(cin, cout, 3, padding=1),
            nn.BatchNorm2d(cout),
            nn.ReLU(inplace=True),
            nn.Conv2d(cout, cout, 3, padding=1),
            nn.BatchNorm2d(cout),
            nn.ReLU(inplace=True),
        )
    def forward(self, x):
        return self.net(x)


def _infer_n_classes_from_state_dict(sd: dict, default: int = 3) -> int:
    try:
        w = sd.get("out.weight", None)
        if w is not None and hasattr(w, "shape"):
            return int(w.shape[0])
    except Exception:
        pass
    return int(default)

class UNetBN(nn.Module):
    """3-level U-Net with BatchNorm. Matches keys like e1/e2/e3/b/u3/d3/.../out."""
    def __init__(self, in_ch: int = 3, n_classes: int = 3, c1: int = 32, c2: int = 64, c3: int = 128, cb: int = 256):
        super().__init__()
        self.e1 = ConvBNReLU(in_ch, c1)
        self.p1 = nn.MaxPool2d(2)
        self.e2 = ConvBNReLU(c1, c2)
        self.p2 = nn.MaxPool2d(2)
        self.e3 = ConvBNReLU(c2, c3)
        self.p3 = nn.MaxPool2d(2)

        self.b = ConvBNReLU(c3, cb)

        self.u3 = nn.ConvTranspose2d(cb, c3, 2, stride=2)
        self.d3 = ConvBNReLU(c3 + c3, c3)
        self.u2 = nn.ConvTranspose2d(c3, c2, 2, stride=2)
        self.d2 = ConvBNReLU(c2 + c2, c2)
        self.u1 = nn.ConvTranspose2d(c2, c1, 2, stride=2)
        self.d1 = ConvBNReLU(c1 + c1, c1)

        self.out = nn.Conv2d(c1, n_classes, 1)

    def forward(self, x):
        e1 = self.e1(x)
        e2 = self.e2(self.p1(e1))
        e3 = self.e3(self.p2(e2))
        b = self.b(self.p3(e3))

        u3 = self.u3(b)
        d3 = self.d3(torch.cat([u3, e3], dim=1))
        u2 = self.u2(d3)
        d2 = self.d2(torch.cat([u2, e2], dim=1))
        u1 = self.u1(d2)
        d1 = self.d1(torch.cat([u1, e1], dim=1))
        return self.out(d1)


def _pick_model(n_classes: int, ckpt_path: Path | None) -> nn.Module:
    """Auto-select model class based on checkpoint key style AND output channels."""
    if ckpt_path and ckpt_path.exists():
        try:
            sd = torch.load(ckpt_path, map_location="cpu")
            if isinstance(sd, dict) and any(k.startswith("e1.") for k in sd.keys()):
                return UNetBN(in_ch=3, n_classes=n_classes)
        except Exception:
            pass
    return TinyUNet(n_classes)


def _dice_score(pred: torch.Tensor, target: torch.Tensor, eps: float = 1e-6) -> float:
    """Binary Dice score with safe empty-target handling.

    IMPORTANT: If the target has no positive pixels, we return 0.0 (not 1.0).
    This prevents the check loop from falsely reporting near-perfect dice when
    the GT mask is missing/blank or mis-loaded.
    """
    pred = pred.float()
    target = target.float()
    t_sum = float(target.sum().item())
    p_sum = float(pred.sum().item())
    if t_sum < 1.0:
        # No GT positives -> treat as invalid/worst case for our use.
        return 0.0
    inter = float((pred * target).sum().item())
    denom = p_sum + t_sum
    return float((2*inter + eps) / (denom + eps))


def _save_check_debug(img_path: Path, mask_path: Path, pred: torch.Tensor, tgt: torch.Tensor, out_dir: Path) -> None:
    """Save the exact pred/gt masks used for the check Dice.

    If your overlay looks wrong but Dice is high, these files will show whether
    the GT mask was empty/incorrect, or the prediction was accidentally
    thresholded into an all-ones mask.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    pred_u8 = (pred.detach().cpu().numpy().astype(np.uint8) * 255)
    tgt_u8 = (tgt.detach().cpu().numpy().astype(np.uint8) * 255)
    Image.fromarray(pred_u8).save(out_dir / "check_pred_dice.png")
    Image.fromarray(tgt_u8).save(out_dir / "check_gt_dice.png")
    meta = (
        f"img_path: {img_path}\n"
        f"mask_path: {mask_path}\n"
        f"pred_nonzero: {int((pred_u8>0).sum())}\n"
        f"tgt_nonzero: {int((tgt_u8>0).sum())}\n"
    )
    (out_dir / "check_dice_meta.txt").write_text(meta, encoding="utf-8")

def _eval_check_pair(model, device, img_path: Path, mask_path: Path, n_classes: int, out_dir: Path | None = None) -> float:
    model.eval()
    if out_dir is None:
        out_dir = Path(os.environ.get('MT_CHECK_OUTDIR','')).expanduser() if os.environ.get('MT_CHECK_OUTDIR','') else None
    # default: alongside project root if possible
    if out_dir is not None:
        out_dir.mkdir(parents=True, exist_ok=True)

    img = Image.open(img_path).convert("RGB")
    msk = Image.open(mask_path).convert("RGB")

    x = np.asarray(img).astype(np.float32) / 255.0
    x = torch.from_numpy(x).permute(2,0,1).unsqueeze(0).to(device)

    y_rgb = np.asarray(msk).astype(np.uint8)
    y = _mask_to_classes(y_rgb, n_classes)
    y = torch.from_numpy(y).to(device)
    ignore_cyan = bool(int(os.environ.get('MT_IGNORE_CYAN', '1')))
    ignore = torch.from_numpy(_cyan_ignore_mask(y_rgb).astype(np.bool_)).to(device) if ignore_cyan else None

    logits = model(x)  # (1,C,H,W)
    if n_classes <= 2:
        # binary: take foreground prob
        if logits.shape[1] == 1:
            prob = torch.sigmoid(logits)[0,0]
        else:
            prob = torch.softmax(logits, dim=1)[0,1]
        pred = (prob > 0.5).to(torch.uint8)
        tgt = (y > 0).to(torch.uint8)
        if ignore is not None:
            pred = pred.masked_fill(ignore, 0)
            tgt = tgt.masked_fill(ignore, 0)
        if out_dir is not None:
            _save_check_debug(img_path, mask_path, pred, tgt, out_dir)
        return _dice_score(pred, tgt)
    else:
        pred = torch.argmax(logits, dim=1)[0].to(torch.uint8)
        # Dice averaged across non-background classes
        scores=[]
        for cls in range(1,n_classes):
            scores.append(_dice_score((pred==cls).to(torch.uint8),(y==cls).to(torch.uint8)))
        return float(np.mean(scores)) if scores else 0.0


@torch.no_grad()
def _write_check_overlay(model, device, img_path: Path, out_path: Path, n_classes: int):
    """Save an overlay PNG with predicted foreground drawn in blue."""
    model.eval()
    img = Image.open(img_path).convert("RGB")
    x = np.asarray(img).astype(np.float32) / 255.0
    xt = torch.from_numpy(x).permute(2,0,1).unsqueeze(0).to(device)

    logits = model(xt)
    if n_classes <= 2:
        if logits.shape[1] == 1:
            prob = torch.sigmoid(logits)[0,0]
        else:
            prob = torch.softmax(logits, dim=1)[0,1]
        pred = (prob > 0.5).cpu().numpy().astype(np.uint8)
    else:
        pred = torch.argmax(logits, dim=1)[0].cpu().numpy().astype(np.uint8)
        pred = (pred > 0).astype(np.uint8)

    base = (x * 255.0).astype(np.uint8)
    # blue overlay where pred==1
    blue = np.zeros_like(base)
    blue[..., 2] = 255
    alpha = 0.55
    m = pred.astype(bool)
    base[m] = (base[m] * (1 - alpha) + blue[m] * alpha).astype(np.uint8)

    Image.fromarray(base).save(out_path)


@torch.no_grad()
def _write_check_artifacts(model, device, img_path: Path, mask_path: Path, out_dir: Path, n_classes: int):
    """Write a predictable set of files for debugging/troubleshooting.

    Files written:
      - check_pred.png            (binary prediction mask)
      - check_gt.png              (binary ground-truth mask extracted from label overlay)
      - check_pred_edge.png       (derived edge mask from prediction)
      - check_pred_overlay.png    (RGB overlay; uses edge mask)
      - check_meta.txt            (paths + basic stats + env + model out channels)
    """
    out_dir.mkdir(parents=True, exist_ok=True)

    img = Image.open(img_path).convert("RGB")
    msk = Image.open(mask_path).convert("RGB")

    x = np.asarray(img).astype(np.float32) / 255.0
    xt = torch.from_numpy(x).permute(2, 0, 1).unsqueeze(0).to(device)

    y_rgb = np.asarray(msk).astype(np.uint8)
    y = _mask_to_classes(y_rgb, n_classes)
    tgt = (y > 0).astype(np.uint8) * 255

    logits = model(xt)
    if n_classes <= 2:
        if logits.shape[1] == 1:
            prob = torch.sigmoid(logits)[0, 0]
        else:
            prob = torch.softmax(logits, dim=1)[0, 1]
        pred = (prob > 0.5).detach().cpu().numpy().astype(np.uint8) * 255
    else:
        pred_cls = torch.argmax(logits, dim=1)[0].detach().cpu().numpy().astype(np.uint8)
        pred = (pred_cls > 0).astype(np.uint8) * 255

    # Save masks
    Image.fromarray(pred).save(out_dir / "check_pred.png")
    Image.fromarray(tgt).save(out_dir / "check_gt.png")

    # Always also save a derived edge mask from the prediction (even in single-head mode).
    pred_bool = (pred > 0)
    edge_bool = _binary_edge(pred_bool, r=1)
    edge_u8 = (edge_bool.astype(np.uint8) * 255)
    Image.fromarray(edge_u8).save(out_dir / "check_pred_edge.png")

    # Save overlay (prefer edge overlay for readability)
    img_u8 = (x * 255.0).astype(np.uint8)
    overlay = _render_blue_overlay(img_u8, edge_bool, alpha=0.55)
    Image.fromarray(overlay).save(out_dir / "check_pred_overlay.png")

    # Save basic stats
    pred_nz = int((pred > 0).sum())
    tgt_nz = int((tgt > 0).sum())
    out_ch = int(logits.shape[1]) if hasattr(logits, "shape") and len(logits.shape) >= 2 else -1
    mt_hybrid = os.environ.get("MT_HYBRID", "")
    meta = (
        f"img_path: {img_path}\n"
        f"mask_path: {mask_path}\n"
        f"MT_HYBRID: {mt_hybrid}\n"
        f"model_out_channels: {out_ch}\n"
        f"pred_nonzero: {pred_nz}\n"
        f"tgt_nonzero: {tgt_nz}\n"
        f"pred_frac: {pred_nz / (pred.size + 1e-9):.6f}\n"
        f"tgt_frac: {tgt_nz / (tgt.size + 1e-9):.6f}\n"
    )
    (out_dir / "check_meta.txt").write_text(meta, encoding="utf-8")

def main():
    if len(sys.argv) < 2:
        print("Usage: python -m mt.train_worker <project_root>")
        sys.exit(2)

    root = Path(sys.argv[1]).resolve()
    data_root, model_root, output_root = map(Path, _resolve_paths(str(root)))
    data_root = data_root.resolve()
    model_root = model_root.resolve()
    output_root = output_root.resolve()
    print(f"[paths] data_root={data_root}")
    print(f"[paths] model_root={model_root}")
    print(f"[paths] output_root={output_root}")
    # Predictable outputs location (no guessing where files ended up)
    out_root = output_root
    out_latest = out_root / "latest"
    out_latest.mkdir(parents=True, exist_ok=True)
    img_dir = data_root / "train" / "images"
    msk_dir = data_root / "train" / "masks"
    print(f"[train] train_images_dir={img_dir}")
    print(f"[train] train_masks_dir={msk_dir}")
    try:
        n_img = len(list(img_dir.glob('*.png')))
        n_msk = len(list(msk_dir.glob('*.png')))
        print(f"[train] found training images={n_img} masks={n_msk}")
    except Exception as e:
        print(f"[train] WARN could not count training files: {e}")
    imported = _auto_import_legacy_training(data_root)
    if imported:
        print(f"[train] Auto-imported {imported} legacy training pair(s) into {img_dir}.")
    # Model directory: when MT_MODEL_ROOT is set, treat it as the models directory root (per-channel already applied).
    _mr_env = _get_env_path('MT_MODEL_ROOT')
    if _mr_env:
        models_dir = Path(model_root)
    else:
        models_dir = Path(model_root) / 'models'
    models_dir.mkdir(parents=True, exist_ok=True)
    print(f"[paths] models_dir={models_dir}")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[train] device={device}")

    # Choose model to (re)train: checkpoint, external_model, or fresh.
    ckpt = models_dir / "checkpoint.pt"
    ext = models_dir / "external_model.pt"
    # Canonical output path for the latest trained weights
    out_path = ext
    load_path = ext if ext.exists() else (ckpt if ckpt.exists() else None)

    # We run binary segmentation (background vs pillars). Walls are ignored for now.
    n_classes = 2
    # Dataset converts masks into valid class indices for the chosen n_classes.
    ds = TileDataset(str(img_dir), str(msk_dir), size=300, n_classes=n_classes)
    check_pair = _find_check_pair(data_root)
    if check_pair:
        print(f"[train] Found check pair: {check_pair[0].name} / {check_pair[1].name}")
    else:
        print("[train] No check pair found (optional).")
    if len(ds) < 5:
        print(f"[train] Not enough labeled tiles yet ({len(ds)}). Need at least ~5 to start.")
        return

    dl = DataLoader(ds, batch_size=4, shuffle=True, num_workers=0)

    model = _pick_model(n_classes, load_path)
    model.to(device)

    # If continuing from an existing checkpoint, actually load it (and drop the wall class if present).
    if load_path and load_path.exists():
        sd = torch.load(load_path, map_location="cpu")
        if isinstance(sd, dict) and "model" in sd and isinstance(sd["model"], dict):
            sd = sd["model"]
        if isinstance(sd, dict):
            sd = _coerce_state_dict_n_classes(sd, n_classes)
        model.load_state_dict(sd, strict=False)
        print(f"[train] Loaded model weights: {load_path.name} (n_classes={n_classes})")


    if load_path is not None:
        print(f"[train] Loaded model for incremental training: {load_path.name}")

    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    loss_fn = nn.CrossEntropyLoss()

    
    # --- training loop (with optional check-pair early stopping) ---
    # Target dice threshold (for early stopping / reporting)
    # Historical env names: MT_CHECK_TARGET (older) vs MT_CHECK_TARGET_DICE (current)
    _t_raw = os.environ.get("MT_CHECK_TARGET_DICE", os.environ.get("MT_CHECK_TARGET", "0.90"))
    try:
        target_dice = float(_t_raw)
    except Exception:
        target_dice = 0.90
    max_epochs = int(os.environ.get("MT_MAX_EPOCHS", "200"))

    best_dice = -1.0
    best_steps = 0
    steps = 0

    for epoch in range(1, max_epochs + 1):
        model.train()
        running = 0.0
        n_batches = 0

        for batch in dl:
            if len(batch) == 2:
                x, y = batch
                ignore = None
            else:
                x, y, ignore = batch
            x = x.to(device)
            y = y.to(device)
            if ignore is not None:
                ignore = ignore.to(device)

            opt.zero_grad()
            logits = model(x)

            if n_classes <= 2:
                # binary segmentation: foreground vs background
                if logits.shape[1] == 1:
                    # model emits a single logit -> use BCEWithLogits
                    y_bin = (y > 0).float().unsqueeze(1)
                    loss_map = torch.nn.functional.binary_cross_entropy_with_logits(logits, y_bin, reduction='none')
                    if ignore is not None:
                        keep = (~ignore).unsqueeze(1)
                        loss = loss_map[keep].mean()
                    else:
                        loss = loss_map.mean()
                else:
                    if ignore is not None:
                        y_ce = y.clone()
                        y_ce[ignore] = 255
                        loss = torch.nn.functional.cross_entropy(logits, y_ce, ignore_index=255)
                    else:
                        loss = torch.nn.functional.cross_entropy(logits, y)
            else:
                # multiclass legacy mode (if used)
                loss = torch.nn.functional.cross_entropy(logits, y)

            loss.backward()
            opt.step()

            running += float(loss.item())
            n_batches += 1
            steps += 1

            if steps % 200 == 0:
                sd = {k: v.detach().cpu() for k, v in model.state_dict().items()}
                torch.save(sd, out_path)
                print(f"[train] saved {out_path.name} (steps={steps})")

        avg_loss = running / max(1, n_batches)
        msg = f"[train] epoch={epoch}/{max_epochs}  loss={avg_loss:.4f}"

        if check_pair:
            check_out = root / 'outputs' / 'check'
            check_out.mkdir(parents=True, exist_ok=True)
            dice = _eval_check_pair(model, device, check_pair[0], check_pair[1], n_classes=n_classes, out_dir=check_out)
            msg += f"  check_dice={dice:.4f}  target={target_dice:.2f}"
            if dice > best_dice:
                best_dice = dice
                best_steps = steps
                sd = {k: v.detach().cpu() for k, v in model.state_dict().items()}
                torch.save(sd, out_path)
                print(f"[train] new best -> saved {out_path.name} (dice={best_dice:.4f}, steps={best_steps})")
                try:
                    # Always write these artifacts into outputs/latest
                    _write_check_artifacts(model, device, check_pair[0], check_pair[1], out_latest, n_classes=n_classes)
                    print(f"[train] wrote check artifacts -> {out_latest}")
                except Exception as e:
                    print(f"[train] check artifact write failed: {e}")
            if dice >= target_dice:
                print(msg)
                print(f"[train] target reached (dice={dice:.4f} >= {target_dice:.2f}). Stopping.")
                break

        print(msg)

    # Final save (if we never had a check pair, or never improved)
    if not out_path.exists():
        sd = {k: v.detach().cpu() for k, v in model.state_dict().items()}
        torch.save(sd, out_path)
        print(f"[train] saved {out_path.name} (final)")

    return 0


if __name__ == "__main__":
    main()