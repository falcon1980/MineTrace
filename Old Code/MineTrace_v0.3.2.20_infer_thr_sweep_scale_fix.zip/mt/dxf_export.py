
from __future__ import annotations
from pathlib import Path

import ezdxf
import numpy as np
from PIL import Image

from .project import Project, TileRec
from .image_io import load_document_to_numpy
from .vectorize import prob_to_polylines


def export_project_to_dxf(project: Project, out_dxf: str):
    out_dxf = str(Path(out_dxf).resolve())
    out_dir = Path(out_dxf).parent

    doc = ezdxf.new(dxfversion="R2010")
    msp = doc.modelspace()

    for c in project.get_classes():
        lname = c["layer"]
        if lname not in doc.layers:
            doc.layers.new(name=lname)

    # attach raster underlays
    for d in project.list_documents():
        img = load_document_to_numpy(d.cache_path)
        h, w = img.shape[:2]
        png_path = out_dir / f"{d.doc_id}_underlay.png"
        Image.fromarray(img).save(png_path)
        image_def = doc.add_image_def(filename=str(png_path), size_in_pixel=(w, h))
        msp.add_image(image_def, insert=(0, 0), size_in_units=(w, h))

    labels = project.list_all_labels()
    tiles_raw = project._read_json(Path(project.tiles_path))["tiles"]
    tiles = [TileRec(**t) for t in tiles_raw]
    tile_map = {(t.doc_id, t.tile_id): t for t in tiles}

    for key, polys in labels.items():
        doc_id, tile_id = key.split(":")
        tile = tile_map.get((doc_id, tile_id))
        if tile is None:
            continue
        for pl in polys:
            layer = "PILLARS" if pl.class_name.lower().startswith("pillar") else "WALLS"
            pts = [(tile.x + p[0], tile.y + p[1]) for p in pl.points]
            if len(pts) < 2:
                continue
            msp.add_lwpolyline(pts, dxfattribs={"layer": layer})

    doc.saveas(out_dxf)


def export_predictions_to_dxf(project: Project, doc_id: str, out_dxf: str, settings: dict):
    """
    Exports predicted polylines from exports/<doc_id>/pred_*.png
    """
    out_dxf = str(Path(out_dxf).resolve())
    out_dir = Path(out_dxf).parent

    ex_dir = Path(project.root) / "exports" / doc_id
    p1 = ex_dir / "pred_pillars.png"
    p2 = ex_dir / "pred_walls.png"
    if not (p1.exists() and p2.exists()):
        raise RuntimeError("Prediction maps not found. Run Predict first.")

    prob_p = np.array(Image.open(p1).convert("L"), dtype=np.uint8)
    prob_w = np.array(Image.open(p2).convert("L"), dtype=np.uint8)

    docrec = project.get_document(doc_id)
    img = load_document_to_numpy(docrec.cache_path)
    h, w = img.shape[:2]
    if prob_p.shape[:2] != (h, w):
        raise RuntimeError("Prediction maps size mismatch with document.")

    doc = ezdxf.new(dxfversion="R2010")
    msp = doc.modelspace()
    if "MT_PILLARS" not in doc.layers:
        doc.layers.new(name="MT_PILLARS")
    if "MT_WALLS" not in doc.layers:
        doc.layers.new(name="MT_WALLS")

    # raster underlay for this doc
    png_path = out_dir / f"{doc_id}_underlay.png"
    Image.fromarray(img).save(png_path)
    image_def = doc.add_image_def(filename=str(png_path), size_in_pixel=(w, h))
    msp.add_image(image_def, insert=(0, 0), size_in_units=(w, h))

    bridge_gap = int(settings.get("bridge_gap", 2))
    merge_radius = int(settings.get("merge_radius", 1))
    simp = int(settings.get("simplify", 2))

    pillars_polys = prob_to_polylines(prob_p, int(settings.get("thr_pillars", 140)), bridge_gap, merge_radius, simp)
    walls_polys = prob_to_polylines(prob_w, int(settings.get("thr_walls", 140)), bridge_gap, merge_radius, simp)

    # NOTE re: merging: default merge_radius is low; user can raise bridge_gap for connectivity without aggressive merging.
    for poly in pillars_polys:
        if len(poly) >= 2:
            msp.add_lwpolyline(poly, dxfattribs={"layer": "MT_PILLARS"})
    for poly in walls_polys:
        if len(poly) >= 2:
            msp.add_lwpolyline(poly, dxfattribs={"layer": "MT_WALLS"})

    doc.saveas(out_dxf)
