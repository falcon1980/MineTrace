
import sys, os
from pathlib import Path

def main():
    root = Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path('.').resolve()
    out = root / 'outputs' / 'check'
    print(f"[debug] outputs/check folder: {out}")
    if not out.exists():
        print("[debug] (does not exist yet) Run training check loop first.")
        return 0
    pngs = sorted(out.glob("*.png"))
    for p in pngs:
        print(p)
    return 0

if __name__=='__main__':
    raise SystemExit(main())
