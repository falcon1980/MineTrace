import sys
from pathlib import Path
import os

# --- Persistent data roots (optional) ---
def _get_env_path(name, default=None):
    v = os.environ.get(name, default)
    if v is None:
        return None
    v = str(v).strip().strip('"').strip("'")
    return v

def _resolve_paths(project_root):
    """Return (data_root, model_root, output_root)."""
    data_root = _get_env_path("MT_DATA_ROOT")
    model_root = _get_env_path("MT_MODEL_ROOT")
    output_root = _get_env_path("MT_OUTPUT_ROOT")
    if not data_root:
        data_root = project_root
    if not model_root:
        model_root = project_root
    if not output_root:
        output_root = project_root
    ch = _get_env_path("MT_CHANNEL")
    if ch:
        data_root = str(Path(data_root) / ch)
        model_root = str(Path(model_root) / ch)
        output_root = str(Path(output_root) / ch)
    return data_root, model_root, output_root

import numpy as np
from PIL import Image

import torch

def _coerce_state_dict_n_classes(sd: dict, n_classes: int) -> dict:
    """Slice checkpoint head weights/bias (out.*) to match n_classes."""
    if not isinstance(sd, dict):
        return sd
    for w_key, b_key in [("out.weight", "out.bias"), ("out.conv.weight", "out.conv.bias")]:
        if w_key in sd and hasattr(sd[w_key], "shape") and len(getattr(sd[w_key], "shape")) == 4:
            if int(sd[w_key].shape[0]) != int(n_classes):
                sd[w_key] = sd[w_key][:n_classes].contiguous()
            if b_key in sd and b_key in sd and hasattr(sd[b_key], "shape") and len(getattr(sd[b_key], "shape")) == 1 and int(sd[b_key].shape[0]) != int(n_classes):
                sd[b_key] = sd[b_key][:n_classes].contiguous()
    return sd


from mt.project import Project
from mt.image_io import load_document_to_numpy
from mt.train_worker import TinyUNet, UNetBN, line_emphasis


def _infer_n_classes_from_state_dict(sd: dict, default: int = 2) -> int:
    try:
        w = sd.get("out.weight", None)
        if w is not None and hasattr(w, "shape"):
            return int(w.shape[0])
    except Exception:
        pass
    return int(default)


def _pick_model(sd: dict | None, fallback_n_classes: int = 2):
    n_classes = fallback_n_classes
    if sd is not None:
        n_classes = min(2, _infer_n_classes_from_state_dict(sd, default=fallback_n_classes))

    if sd is not None and any(k.startswith("e1.") for k in sd.keys()):
        return UNetBN(in_ch=3, n_classes=n_classes), n_classes
    return TinyUNet(n_classes), n_classes


def _infer_tiled(model, img_rgb: np.ndarray, device, tile_size: int = 128, overlap: float = 0.5) -> np.ndarray:
    H, W, _ = img_rgb.shape
    ts = int(max(64, min(512, tile_size)))
    ov = float(max(0.0, min(0.9, overlap)))
    step = max(1, int(round(ts * (1.0 - ov))))

    try:
        C = int(model.out.out_channels)  # type: ignore[attr-defined]
    except Exception:
        C = 2

    acc = np.zeros((C, H, W), dtype=np.float32)
    wgt = np.zeros((H, W), dtype=np.float32)

    win1 = 0.5 - 0.5 * np.cos(2.0 * np.pi * np.arange(ts, dtype=np.float32) / max(1, ts - 1))
    win2 = win1[:, None] * win1[None, :]
    win2 /= (win2.max() + 1e-6)

    # NOTE: Using a constant (white) pad at tile edges can create strong, repeated
    # high-contrast borders that the model "sees" at every tile boundary and can
    # imprint as grid/stripe artifacts in the stitched output.
    # Prefer reflected padding so tile boundaries look like natural continuation.

    model.eval()
    with torch.no_grad():
        for y0 in range(0, H, step):
            for x0 in range(0, W, step):
                y1 = min(H, y0 + ts)
                x1 = min(W, x0 + ts)
                rh = y1 - y0
                rw = x1 - x0

                patch = img_rgb[y0:y1, x0:x1, :]
                if rh == ts and rw == ts:
                    tile = patch
                else:
                    pad_y = ts - rh
                    pad_x = ts - rw
                    # reflect requires at least 2 pixels; fall back to edge when very small
                    mode = "reflect" if (rh > 1 and rw > 1) else "edge"
                    tile = np.pad(patch, ((0, pad_y), (0, pad_x), (0, 0)), mode=mode)

                x = torch.from_numpy(tile).permute(2, 0, 1).float().unsqueeze(0) / 255.0
                x = x.to(device)

                logits = model(x).squeeze(0)
                # Stitch raw logits, then apply softmax after blending.
                logit_np = logits.detach().cpu().numpy().astype(np.float32)

                ww = win2[:rh, :rw]
                acc[:, y0:y1, x0:x1] += logit_np[:, :rh, :rw] * ww[None, :, :]
                wgt[y0:y1, x0:x1] += ww

    wgt = np.clip(wgt, 1e-6, None)
    acc /= wgt[None, :, :]
    # Convert blended logits -> probabilities
    m = acc.max(axis=0, keepdims=True)
    exp = np.exp(acc - m)
    prob = exp / np.clip(exp.sum(axis=0, keepdims=True), 1e-6, None)
    return prob


def main():
    if len(sys.argv) < 3:
        print("Usage: python -m mt.infer_worker <project_root> <doc_id> [thr_pillars] [thr_walls] [alpha] [tile_size] [overlap]")
        sys.exit(2)

    project_root = sys.argv[1]
    root = Path(project_root).resolve()
    data_root, model_root, output_root = map(Path, _resolve_paths(str(root)))
    data_root = data_root.resolve()
    model_root = model_root.resolve()
    output_root = output_root.resolve()
    print(f"[paths] data_root={data_root}")
    print(f"[paths] model_root={model_root}")
    print(f"[paths] output_root={output_root}")
    doc_id = sys.argv[2]

    def _norm_thr(v):
        """Accept either 0..255 or 0..1 thresholds (backward/flag compatibility)."""
        try:
            fv = float(v)
        except Exception:
            return 140
        if fv <= 1.0:
            return int(round(fv * 255.0))
        return int(round(fv))

    thr_pillars = _norm_thr(sys.argv[3]) if len(sys.argv) > 3 else 140
    thr_walls   = _norm_thr(sys.argv[4]) if len(sys.argv) > 4 else 140
    alpha       = int(float(sys.argv[5])) if len(sys.argv) > 5 else 160

    def _pick_thr_sweep(img_u8, base_thr, offsets_csv, target_frac=0.03):
        # img_u8: uint8 0..255 probability map
        offs = []
        for tok in (offsets_csv or "").split(","):
            tok = tok.strip()
            if not tok:
                continue
            try:
                offs.append(int(float(tok)))
            except Exception:
                pass
        if not offs:
            offs = [-80, -60, -40, -20, -10, 0, 10, 20, 40, 60, 80]
        best_thr = max(0, min(255, int(base_thr)))
        best_score = -1e18
        for off in offs:
            thr = max(0, min(255, int(base_thr) + int(off)))
            m = (img_u8 >= thr)
            frac = float(m.mean()) if m.size else 0.0
            # Reject almost empty or almost full masks hard
            if frac < 0.0005:
                score = -1e9 - (0.0005 - frac) * 1e6
            elif frac > 0.40:
                score = -1e9 - (frac - 0.40) * 1e6
            else:
                # Prefer frac close to target_frac
                score = -abs(frac - target_frac)
            if score > best_score:
                best_score = score
                best_thr = thr
        return best_thr

    tile_size = int(sys.argv[6]) if len(sys.argv) > 6 else 128
    overlap = float(sys.argv[7]) if len(sys.argv) > 7 else 0.50

    p = Project.load(project_root)
    doc = p.get_document(doc_id)

    img_bgr = load_document_to_numpy(doc.cache_path)
    img_rgb0 = img_bgr[..., ::-1].copy()
    img_rgb = line_emphasis(img_rgb0)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"[infer] device={device}")

    # Model paths (support persistent roots + per-channel models)
    data_root, model_root, output_root = _resolve_paths(project_root)
    models_dir = Path(model_root)
    models_dir.mkdir(parents=True, exist_ok=True)
    ckpt = models_dir / "checkpoint.pt"
    ext = models_dir / "external_model.pt"
    load_path = ext if ext.exists() else ckpt
    ch = (os.environ.get('MT_CHANNEL') or '').lower().strip()
    pos_color = (os.environ.get('MT_POS_COLOR','yellow') or 'yellow').lower()
    sd = None
    if load_path.exists():
        sd = torch.load(load_path, map_location="cpu")

    model, n_classes = _pick_model(sd, fallback_n_classes=2)
    model = model.to(device)

    if sd is not None:
        model.load_state_dict(sd)
        print(f"[infer] Loaded model: {load_path.name} (n_classes={n_classes})")
    else:
        print("[infer] WARNING: no model found (checkpoint.pt / external_model.pt).")

    prob = _infer_tiled(model, img_rgb, device, tile_size=tile_size, overlap=overlap)

    if n_classes >= 3:
        prob_pillars = prob[1]
        prob_walls = prob[2]
    elif n_classes == 2:
        # 2-class checkpoints are treated as [background, pillars]
        prob_pillars = prob[1]
        prob_walls = np.zeros_like(prob_pillars)
    else:
        prob_pillars = prob[0]
        prob_walls = np.zeros_like(prob[0])

    pillars = (prob_pillars * 255).astype(np.uint8)
    walls = (prob_walls * 255).astype(np.uint8)
    print(f"[infer] tiled={tile_size}px overlap={overlap:.2f} | prob range pillars: {pillars.min()}..{pillars.max()} walls: {walls.min()}..{walls.max()}")

    out_dir = Path(p.exports_dir) / doc_id
    out_dir.mkdir(parents=True, exist_ok=True)

    # Write channel-specific probability map (do not clobber the other channel's file)
    if ch.startswith('wall') or pos_color.startswith('c'):
        Image.fromarray(walls).save(out_dir / "pred_walls.png")
    else:
        Image.fromarray(pillars).save(out_dir / "pred_pillars.png")

    # Rebuild combined overlay from whatever channel files exist
    base = Image.fromarray(img_rgb0).convert("RGBA")
    ov_img = Image.new("RGBA", base.size, (0, 0, 0, 0))

    p_path = out_dir / "pred_pillars.png"
    w_path = out_dir / "pred_walls.png"
    if p_path.exists():
        pillars_img = np.array(Image.open(p_path).convert('L'))
    else:
        pillars_img = np.zeros((base.size[1], base.size[0]), dtype=np.uint8)
    if w_path.exists():
        walls_img = np.array(Image.open(w_path).convert('L'))
    else:
        walls_img = np.zeros((base.size[1], base.size[0]), dtype=np.uint8)

    # Optional threshold sweep at inference time (helps when probability scale drifts)
    if os.environ.get("MT_INFER_THR_SWEEP", "0").strip() == "1":
        offs = os.environ.get("MT_INFER_THR_SWEEP_OFFSETS", "")
        thr_pillars = _pick_thr_sweep(pillars_img, thr_pillars, offs, target_frac=0.03)
        thr_walls   = _pick_thr_sweep(walls_img,   thr_walls,   offs, target_frac=0.01)

    p_mask = (pillars_img >= thr_pillars).astype(np.uint8) * alpha
    w_mask = (walls_img >= thr_walls).astype(np.uint8) * alpha
    p_layer = Image.new("RGBA", base.size, (255, 255, 0, 0))
    w_layer = Image.new("RGBA", base.size, (0, 255, 255, 0))
    p_layer.putalpha(Image.fromarray(p_mask))
    w_layer.putalpha(Image.fromarray(w_mask))
    ov_img = Image.alpha_composite(ov_img, p_layer)
    ov_img = Image.alpha_composite(ov_img, w_layer)
    comp = Image.alpha_composite(base, ov_img).convert("RGB")
    comp.save(out_dir / "pred_overlay.png")

    print("[infer] wrote:", out_dir)


if __name__ == "__main__":
    main()