
import numpy as np
import cv2
from .project import PolylineRec

def rasterize_tile_labels(w: int, h: int, polylines: list[PolylineRec], classes: list[dict]) -> np.ndarray:
    class_to_id = {c["name"]: i+1 for i, c in enumerate(classes)}
    mask = np.zeros((h, w), dtype=np.uint8)

    for pl in polylines:
        cid = class_to_id.get(pl.class_name, 0)
        if cid == 0 or len(pl.points) < 2:
            continue
        pts = np.array(pl.points, dtype=np.float32)
        pts_i = np.round(pts).astype(np.int32)
        thickness = max(1, int(pl.thickness))
        for i in range(1, len(pts_i)):
            x1, y1 = pts_i[i-1]
            x2, y2 = pts_i[i]
            cv2.line(mask, (x1, y1), (x2, y2), int(cid), thickness=thickness, lineType=cv2.LINE_AA)

    return mask


def render_label_overlay(w: int, h: int, polylines: list[PolylineRec], classes: list[dict]) -> np.ndarray:
    """Render an RGB overlay of the polylines using class colors.

    Colors (BGR in cv2): Pillars=yellow, Walls=cyan, default=magenta.
    """
    overlay = np.zeros((h, w, 3), dtype=np.uint8)

    def color_for(name: str):
        n = (name or "").lower()
        if "pillar" in n:
            return (0, 255, 255)  # yellow
        if "wall" in n:
            return (255, 255, 0)  # cyan
        return (255, 0, 255)     # magenta fallback

    for pl in polylines:
        if len(pl.points) < 2:
            continue
        col = color_for(pl.class_name)
        pts = np.array(pl.points, dtype=np.float32)
        pts_i = np.round(pts).astype(np.int32)
        thickness = max(1, int(pl.thickness))
        for i in range(1, len(pts_i)):
            x1, y1 = pts_i[i-1]
            x2, y2 = pts_i[i]
            cv2.line(overlay, (x1, y1), (x2, y2), col, thickness=thickness, lineType=cv2.LINE_AA)

    return overlay
