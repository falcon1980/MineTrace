from __future__ import annotations
from pathlib import Path
import re
import numpy as np
from PIL import Image
import cv2


def _mask_by_hsv(img_rgb: np.ndarray, hsv_lo, hsv_hi) -> np.ndarray:
    hsv = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2HSV)
    lo = np.array(hsv_lo, dtype=np.uint8)
    hi = np.array(hsv_hi, dtype=np.uint8)
    return cv2.inRange(hsv, lo, hi)


def _find_pairs(folder: Path):
    exts = {".png", ".jpg", ".jpeg"}
    files = [p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in exts]
    pairs = {}
    for p in files:
        stem = p.stem
        m = re.match(r"^(.*?)([abAB])$", stem)
        if not m:
            continue
        base = m.group(1)
        tag = m.group(2).lower()
        pairs.setdefault(base, {})
        pairs[base][tag] = p

    out = []
    for base, d in pairs.items():
        if "a" in d and "b" in d:
            out.append((base, d["a"], d["b"]))
    return sorted(out, key=lambda x: x[0].lower())


def _remove_small_components(binary_mask_u8: np.ndarray, min_area: int) -> np.ndarray:
    """
    Remove connected components smaller than min_area.
    binary_mask_u8: 0/255 image.
    Returns 0/255 image.
    """
    if min_area <= 0:
        return binary_mask_u8
    m = (binary_mask_u8 > 0).astype(np.uint8)
    n, labels, stats, _ = cv2.connectedComponentsWithStats(m, connectivity=8)
    out = np.zeros_like(m, dtype=np.uint8)
    for i in range(1, n):
        area = int(stats[i, cv2.CC_STAT_AREA])
        if area >= min_area:
            out[labels == i] = 1
    return (out * 255).astype(np.uint8)


def import_legacy_labeled_tiles(
    project,
    folder: str,
    *,
    data_root_override: str | None = None,
    channel_ids: tuple[str, str] = ("pillars", "walls"),
    min_area_yellow: int = 8,
    min_area_cyan: int = 50,
    yellow_lo=(15, 80, 80),
    yellow_hi=(45, 255, 255),
    cyan_lo=(70, 60, 60),
    cyan_hi=(120, 255, 255),
) -> dict:
    """
    Import paired legacy tiles:
      - *a = original untouched (training image)
      - *b = annotated (used for mask extraction)

    Writes into the *persistent channel data roots*:

      <data_root>/<channel>/train/images/legacy_<base>.png
      <data_root>/<channel>/train/labels/legacy_<base>.png      (viewable overlay, same as *b)
      <data_root>/<channel>/train/masks/legacy_<base>_mask.png  (strokes-only on black, channel color)
      <data_root>/<channel>/train/masks/legacy_<base>_mask_id.png (0/1 debug for that channel)

    Yellow strokes -> pillars channel
    Cyan strokes   -> walls channel
    """
    folder = Path(folder).resolve()

    # Where to write:
    base_root = Path(data_root_override).resolve() if data_root_override else Path(project.root)
    pillars_id, walls_id = channel_ids

    # channel roots (avoid .../pillars/pillars duplication)
    pillars_root = base_root / pillars_id if base_root.name.lower() != pillars_id.lower() else base_root
    walls_root   = base_root / walls_id   if base_root.name.lower() != walls_id.lower() else base_root

    def _ensure_dirs(root: Path):
        img_dir = root / "train" / "images"
        lbl_dir = root / "train" / "labels"
        msk_dir = root / "train" / "masks"
        img_dir.mkdir(parents=True, exist_ok=True)
        lbl_dir.mkdir(parents=True, exist_ok=True)
        msk_dir.mkdir(parents=True, exist_ok=True)
        return img_dir, lbl_dir, msk_dir

    pairs = _find_pairs(folder)
    imported = 0
    skipped = 0
    noise_filtered = 0
    wrote_pillars = 0
    wrote_walls = 0

    for base, pa, pb in pairs:
        try:
            img_clean = np.array(Image.open(pa).convert("RGB"), dtype=np.uint8)
            img_anno  = np.array(Image.open(pb).convert("RGB"), dtype=np.uint8)
        except Exception:
            skipped += 1
            continue

        m_y = _mask_by_hsv(img_anno, yellow_lo, yellow_hi)
        m_c = _mask_by_hsv(img_anno, cyan_lo, cyan_hi)

        m_y2 = _remove_small_components(m_y, int(min_area_yellow))
        m_c2 = _remove_small_components(m_c, int(min_area_cyan))
        if (m_y2 != m_y).any() or (m_c2 != m_c).any():
            noise_filtered += 1
        m_y, m_c = m_y2, m_c2

        has_y = (m_y > 0).any()
        has_c = (m_c > 0).any()
        if not has_y and not has_c:
            skipped += 1
            continue

        # Always save the clean image + overlay label into any channel that has content
        if has_y:
            img_dir, lbl_dir, msk_dir = _ensure_dirs(pillars_root)
            Image.fromarray(img_clean).save(img_dir / f"legacy_{base}.png")
            Image.fromarray(img_anno).save(lbl_dir / f"legacy_{base}.png")

            # strokes-only mask (yellow) + id mask (1 where strokes exist)
            mask_rgb = np.zeros_like(img_clean, dtype=np.uint8)
            mask_rgb[m_y > 0] = (255, 255, 0)  # yellow
            mask_id = np.zeros((img_clean.shape[0], img_clean.shape[1]), dtype=np.uint8)
            mask_id[m_y > 0] = 1
            Image.fromarray(mask_rgb).save(msk_dir / f"legacy_{base}_mask.png")
            Image.fromarray(mask_id).save(msk_dir / f"legacy_{base}_mask_id.png")
            wrote_pillars += 1

        if has_c:
            img_dir, lbl_dir, msk_dir = _ensure_dirs(walls_root)
            Image.fromarray(img_clean).save(img_dir / f"legacy_{base}.png")
            Image.fromarray(img_anno).save(lbl_dir / f"legacy_{base}.png")

            # strokes-only mask (cyan) + id mask (1 where strokes exist)
            mask_rgb = np.zeros_like(img_clean, dtype=np.uint8)
            mask_rgb[m_c > 0] = (0, 255, 255)  # cyan
            mask_id = np.zeros((img_clean.shape[0], img_clean.shape[1]), dtype=np.uint8)
            mask_id[m_c > 0] = 1
            Image.fromarray(mask_rgb).save(msk_dir / f"legacy_{base}_mask.png")
            Image.fromarray(mask_id).save(msk_dir / f"legacy_{base}_mask_id.png")
            wrote_walls += 1

        imported += 1

    return {
        "pairs_found": len(pairs),
        "imported_pairs": imported,
        "skipped_pairs": skipped,
        "noise_filtered_pairs": noise_filtered,
        "wrote_pillars": wrote_pillars,
        "wrote_walls": wrote_walls,
        "base_root": str(base_root),
    }
