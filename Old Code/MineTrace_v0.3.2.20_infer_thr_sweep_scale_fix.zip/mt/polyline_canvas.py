from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional, Tuple

import math

import numpy as np
from PySide6.QtCore import Qt, QPointF
from PySide6.QtGui import QImage, QPixmap, QPainter, QPen
from PySide6.QtWidgets import QWidget

from .project import PolylineRec

CLASS_COLORS = {
    "Pillars": Qt.yellow,
    "Walls": Qt.cyan,
}

@dataclass
class _Polyline:
    class_name: str
    thickness: int
    pts: List[QPointF]


def _dist2(a: QPointF, b: QPointF) -> float:
    dx = float(a.x() - b.x())
    dy = float(a.y() - b.y())
    return dx*dx + dy*dy


def _circle_from_3pts(p1: QPointF, p2: QPointF, p3: QPointF) -> Optional[Tuple[float, float, float]]:
    x1, y1 = float(p1.x()), float(p1.y())
    x2, y2 = float(p2.x()), float(p2.y())
    x3, y3 = float(p3.x()), float(p3.y())

    a = x1 - x2
    b = y1 - y2
    c = x1 - x3
    d = y1 - y3
    e = ((x1*x1 - x2*x2) + (y1*y1 - y2*y2)) / 2.0
    f = ((x1*x1 - x3*x3) + (y1*y1 - y3*y3)) / 2.0
    det = a*d - b*c
    if abs(det) < 1e-6:
        return None
    cx = (d*e - b*f) / det
    cy = (-c*e + a*f) / det
    r = math.hypot(cx - x1, cy - y1)
    return cx, cy, r


def _angle(cx: float, cy: float, p: QPointF) -> float:
    return math.atan2(float(p.y()) - cy, float(p.x()) - cx)


def _sample_arc(p1: QPointF, p2: QPointF, p3: QPointF, n: int = 32) -> Optional[List[QPointF]]:
    circ = _circle_from_3pts(p1, p2, p3)
    if circ is None:
        return None
    cx, cy, r = circ
    a1 = _angle(cx, cy, p1)
    a2 = _angle(cx, cy, p2)
    a3 = _angle(cx, cy, p3)

    def norm(a):
        while a < 0: a += 2*math.pi
        while a >= 2*math.pi: a -= 2*math.pi
        return a

    a1n, a2n, a3n = norm(a1), norm(a2), norm(a3)

    def on_ccw(a_start, a_end, a_mid):
        if a_end >= a_start:
            return a_start <= a_mid <= a_end
        return a_mid >= a_start or a_mid <= a_end

    ccw_contains = on_ccw(a1n, a2n, a3n)

    if ccw_contains:
        sweep = a2n - a1n
        if sweep < 0:
            sweep += 2*math.pi
        angles = [a1n + sweep*(i/(n-1)) for i in range(n)]
    else:
        sweep = a1n - a2n
        if sweep < 0:
            sweep += 2*math.pi
        angles = [a1n - sweep*(i/(n-1)) for i in range(n)]

    pts = [QPointF(cx + r*math.cos(a), cy + r*math.sin(a)) for a in angles]
    pts[0] = QPointF(p1.x(), p1.y())
    pts[-1] = QPointF(p2.x(), p2.y())
    return pts


class PolylineCanvas(QWidget):
    def __init__(self, tile_image: np.ndarray):
        super().__init__()
        self.setMinimumSize(860, 620)
        h, w = tile_image.shape[:2]
        qimg = QImage(tile_image.data, w, h, 3*w, QImage.Format_RGB888)
        self._pix = QPixmap.fromImage(qimg)

        self.active_class = "Pillars"
        self.active_thickness = 3

        self.polys: list[_Polyline] = []
        self._current: _Polyline | None = None

        self._undo_stack: list[list[_Polyline]] = []
        self._redo_stack: list[list[_Polyline]] = []

        # live preview
        self._hover_img_pt: Optional[QPointF] = None

        # arc state
        self._arc_pending = False
        self._arc_start: Optional[QPointF] = None
        self._arc_end: Optional[QPointF] = None

        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.StrongFocus)

    def set_active_class(self, name: str):
        self.active_class = name

    def set_active_thickness(self, t: int):
        self.active_thickness = int(t)

    def load_polylines(self, polylines: list[PolylineRec]):
        self.polys = []
        for p in polylines:
            pts = [QPointF(float(x), float(y)) for x, y in p.points]
            self.polys.append(_Polyline(p.class_name, int(p.thickness), pts))
        self._current = None
        self._reset_arc()
        self.update()

    def export_polylines(self) -> list[PolylineRec]:
        out = []
        for p in self.polys:
            out.append(PolylineRec(
                class_name=p.class_name,
                thickness=p.thickness,
                points=[[float(pt.x()), float(pt.y())] for pt in p.pts],
            ))
        return out

    def _snapshot(self):
        import copy
        self._undo_stack.append(copy.deepcopy(self.polys))
        self._redo_stack.clear()

    def undo(self):
        if not self._undo_stack:
            return
        self._redo_stack.append(self.polys)
        self.polys = self._undo_stack.pop()
        self._current = None
        self._reset_arc()
        self.update()

    def redo(self):
        if not self._redo_stack:
            return
        self._undo_stack.append(self.polys)
        self.polys = self._redo_stack.pop()
        self._current = None
        self._reset_arc()
        self.update()

    def _draw_params(self):
        target = self.rect()
        scaled = self._pix.scaled(target.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        x0 = (target.width() - scaled.width()) // 2
        y0 = (target.height() - scaled.height()) // 2
        sx = scaled.width() / self._pix.width()
        sy = scaled.height() / self._pix.height()
        return scaled, x0, y0, sx, sy

    def widget_to_image(self, wx: float, wy: float):
        scaled, x0, y0, sx, sy = self._draw_params()
        if wx < x0 or wy < y0 or wx > x0 + scaled.width() or wy > y0 + scaled.height():
            return None
        ix = (wx - x0) / sx
        iy = (wy - y0) / sy
        ix = max(0.0, min(ix, self._pix.width() - 1))
        iy = max(0.0, min(iy, self._pix.height() - 1))
        return ix, iy

    def abort_current(self):
        """Abort the current in-progress polyline (does not affect saved polylines)."""
        self._current = None
        self._reset_arc()
        self.update()

    def _reset_arc(self):
        self._arc_pending = False
        self._arc_start = None
        self._arc_end = None

    def _start_if_needed(self):
        if self._current is None:
            self._current = _Polyline(self.active_class, self.active_thickness, [])

    def mouseMoveEvent(self, ev):
        mapped = self.widget_to_image(ev.position().x(), ev.position().y())
        if mapped is None:
            self._hover_img_pt = None
        else:
            self._hover_img_pt = QPointF(mapped[0], mapped[1])
        self.update()

    def mousePressEvent(self, ev):
        if ev.button() == Qt.RightButton:
            self._reset_arc()
            self._finish_polyline()
            return

        if ev.button() != Qt.LeftButton:
            return

        mapped = self.widget_to_image(ev.position().x(), ev.position().y())
        if mapped is None:
            return
        pt = QPointF(mapped[0], mapped[1])

        # Arc radius selection: commit arc
        if self._arc_pending and self._arc_start is not None and self._arc_end is not None:
            self._snapshot()
            self._start_if_needed()
            arc_pts = _sample_arc(self._arc_start, self._arc_end, pt, n=32)
            if arc_pts is None:
                if len(self._current.pts) == 0:
                    self._current.pts.append(QPointF(self._arc_start.x(), self._arc_start.y()))
                self._current.pts.append(QPointF(self._arc_end.x(), self._arc_end.y()))
            else:
                if len(self._current.pts) == 0:
                    self._current.pts.append(QPointF(arc_pts[0].x(), arc_pts[0].y()))
                else:
                    last = self._current.pts[-1]
                    if _dist2(last, arc_pts[0]) > 1e-3:
                        self._current.pts.append(QPointF(arc_pts[0].x(), arc_pts[0].y()))
                for ap in arc_pts[1:]:
                    self._current.pts.append(QPointF(ap.x(), ap.y()))
            self._reset_arc()
            self.update()
            return

        # Shift+Left-click sets arc endpoint
        if (ev.modifiers() & Qt.ShiftModifier):
            if self._current is None or len(self._current.pts) == 0:
                # No start yet: create start point with normal click first
                self._snapshot()
                self._start_if_needed()
                self._current.pts.append(QPointF(pt.x(), pt.y()))
                self.update()
                return
            self._arc_start = self._current.pts[-1]
            self._arc_end = pt
            self._arc_pending = True
            # keep hover point so preview doesn't disappear if mouse doesn't move immediately
            self._hover_img_pt = QPointF(pt.x(), pt.y())
            self.update()
            return

        # Normal point add
        self._snapshot()
        self._start_if_needed()
        self._current.pts.append(QPointF(pt.x(), pt.y()))
        self.update()

    def _finish_polyline(self):
        if self._current is None:
            return

        if self._current.class_name == "Pillars" and len(self._current.pts) >= 3:
            a = self._current.pts[0]
            b = self._current.pts[-1]
            if _dist2(a, b) > 4.0:
                self._current.pts.append(QPointF(a.x(), a.y()))

        if len(self._current.pts) >= 2:
            self.polys.append(self._current)
        self._current = None
        self.update()

    def paintEvent(self, e):
        painter = QPainter(self)
        target = self.rect()
        scaled = self._pix.scaled(target.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        x0 = (target.width() - scaled.width()) // 2
        y0 = (target.height() - scaled.height()) // 2
        painter.drawPixmap(x0, y0, scaled)

        iw = self._pix.width()
        sx = scaled.width() / iw
        sy = scaled.height() / self._pix.height()

        def draw_poly(poly: _Polyline, dashed: bool = False):
            color = CLASS_COLORS.get(poly.class_name, Qt.magenta)
            pen_w = max(1, int(poly.thickness * (sx + sy) / 2))
            style = Qt.SolidLine
            pen = QPen(color, max(1, pen_w), style, Qt.RoundCap, Qt.RoundJoin)
            painter.setPen(pen)
            pts = poly.pts
            for i in range(1, len(pts)):
                a = pts[i-1]
                b = pts[i]
                painter.drawLine(x0 + a.x()*sx, y0 + a.y()*sy,
                                 x0 + b.x()*sx, y0 + b.y()*sy)

        for p in self.polys:
            draw_poly(p, dashed=False)
        if self._current is not None:
            draw_poly(self._current, dashed=False)

        # Live preview
        if self._current is not None and self._hover_img_pt is not None:
            tmp = _Polyline(self.active_class, self.active_thickness, [])
            if self._arc_pending and self._arc_start is not None and self._arc_end is not None:
                try:
                    arc_pts = _sample_arc(self._arc_start, self._arc_end, self._hover_img_pt, n=32)
                    if arc_pts:
                        tmp.pts = arc_pts
                        draw_poly(tmp, dashed=True)
                except Exception:
                    # Never crash paint; just skip preview
                    pass
            else:
                if len(self._current.pts) >= 1:
                    tmp.pts = [self._current.pts[-1], self._hover_img_pt]
                    draw_poly(tmp, dashed=True)
