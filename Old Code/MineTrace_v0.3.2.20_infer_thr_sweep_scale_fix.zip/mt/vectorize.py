
from __future__ import annotations
import numpy as np
import cv2
from skimage.morphology import skeletonize

def _binary_cleanup(bin_img: np.ndarray, bridge_gap: int, merge_radius: int) -> np.ndarray:
    """
    bridge_gap: connect small gaps along lines (closing)
    merge_radius: more aggressive merge (dilation+erosion). Keep low to avoid unwanted merges.
    """
    out = bin_img.copy().astype(np.uint8)

    if bridge_gap > 0:
        k = 2*bridge_gap + 1
        out = cv2.morphologyEx(out, cv2.MORPH_CLOSE, np.ones((k, k), np.uint8))

    if merge_radius > 0:
        k = 2*merge_radius + 1
        out = cv2.dilate(out, np.ones((k, k), np.uint8), iterations=1)
        out = cv2.erode(out, np.ones((k, k), np.uint8), iterations=1)

    return (out > 0).astype(np.uint8)

def _neighbors8(y, x, h, w):
    for dy in (-1,0,1):
        for dx in (-1,0,1):
            if dy==0 and dx==0:
                continue
            yy, xx = y+dy, x+dx
            if 0 <= yy < h and 0 <= xx < w:
                yield yy, xx

def skeleton_to_polylines(skel: np.ndarray) -> list[list[tuple[int,int]]]:
    """
    Convert 1px skeleton to polylines by graph walking.
    Returns list of polylines in (x,y) order.
    """
    sk = (skel > 0).astype(np.uint8)
    h, w = sk.shape
    ys, xs = np.where(sk > 0)
    if len(ys) == 0:
        return []

    # compute degree
    deg = np.zeros_like(sk, dtype=np.uint8)
    for y, x in zip(ys, xs):
        d = 0
        for yy, xx in _neighbors8(y, x, h, w):
            if sk[yy, xx]:
                d += 1
        deg[y, x] = d

    # endpoints: degree 1; junctions: degree >=3
    endpoints = set(zip(ys[deg[ys, xs] == 1], xs[deg[ys, xs] == 1]))
    junctions = set(zip(ys[deg[ys, xs] >= 3], xs[deg[ys, xs] >= 3]))

    visited = set()
    polylines = []

    def walk(start):
        poly = []
        cur = start
        prev = None
        while True:
            poly.append(cur)
            visited.add(cur)
            y, x = cur
            # stop at junction (but include it)
            if cur in junctions and cur != start:
                break

            # pick next neighbor not equal prev and not visited if possible
            neigh = [(yy, xx) for (yy, xx) in _neighbors8(y, x, h, w) if sk[yy, xx]]
            if prev is not None:
                neigh = [n for n in neigh if n != prev]
            if not neigh:
                break

            # prefer unvisited neighbor
            nxt = None
            for n in neigh:
                if n not in visited:
                    nxt = n
                    break
            if nxt is None:
                # all visited -> stop
                break
            prev, cur = cur, nxt
        return poly

    # walk from endpoints first
    for ep in list(endpoints):
        if ep in visited:
            continue
        poly = walk(ep)
        if len(poly) >= 2:
            polylines.append([(x,y) for (y,x) in poly])

    # then walk remaining pixels (loops)
    for y, x in zip(ys, xs):
        pt = (y, x)
        if pt in visited:
            continue
        poly = walk(pt)
        if len(poly) >= 2:
            polylines.append([(x,y) for (y,x) in poly])

    return polylines

def simplify_polyline(pts: list[tuple[float,float]], tol: float) -> list[tuple[float,float]]:
    if tol <= 0 or len(pts) < 3:
        return pts
    # Ramer-Douglas-Peucker
    import math
    def dist_point_line(p, a, b):
        # distance from p to segment ab
        (x,y), (x1,y1), (x2,y2) = p, a, b
        dx, dy = x2-x1, y2-y1
        if dx == 0 and dy == 0:
            return math.hypot(x-x1, y-y1)
        t = ((x-x1)*dx + (y-y1)*dy) / (dx*dx + dy*dy)
        t = max(0, min(1, t))
        px, py = x1 + t*dx, y1 + t*dy
        return math.hypot(x-px, y-py)

    def rdp(points):
        a, b = points[0], points[-1]
        maxd, idx = 0.0, -1
        for i in range(1, len(points)-1):
            d = dist_point_line(points[i], a, b)
            if d > maxd:
                maxd, idx = d, i
        if maxd > tol and idx != -1:
            left = rdp(points[:idx+1])
            right = rdp(points[idx:])
            return left[:-1] + right
        return [a, b]

    return rdp(pts)

def prob_to_polylines(prob_u8: np.ndarray, thr_u8: int, bridge_gap: int, merge_radius: int, simplify_level: int):
    bin_img = (prob_u8 >= thr_u8).astype(np.uint8) * 255
    bin_img = _binary_cleanup(bin_img, bridge_gap=bridge_gap, merge_radius=merge_radius)
    sk = skeletonize(bin_img > 0).astype(np.uint8)
    polylines = skeleton_to_polylines(sk)
    # simplify level: map 0..10 -> tol 0..3 px
    tol = (simplify_level / 10.0) * 3.0
    polylines = [simplify_polyline(p, tol) for p in polylines]
    return polylines
