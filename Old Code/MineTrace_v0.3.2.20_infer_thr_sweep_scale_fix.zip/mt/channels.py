from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, List, Optional

@dataclass(frozen=True)
class ChannelSpec:
    id: str
    display_name: str
    overlay_color: str
    label_color: str
    dxf_layer: str

def default_channels_path(app_root: Path) -> Path:
    return app_root / "channels" / "channels.json"

def load_channels(app_root: Path, path: Optional[Path] = None) -> List[ChannelSpec]:
    path = path or default_channels_path(app_root)
    if not path.exists():
        return []
    data = json.loads(path.read_text(encoding="utf-8"))
    out: List[ChannelSpec] = []
    for c in data.get("channels", []):
        out.append(ChannelSpec(
            id=c["id"],
            display_name=c.get("display_name", c["id"]),
            overlay_color=c.get("overlay_color", "yellow"),
            label_color=c.get("label_color", c.get("overlay_color", "yellow")),
            dxf_layer=c.get("dxf_layer", f"MT_{c['id'].upper()}"),
        ))
    return out
